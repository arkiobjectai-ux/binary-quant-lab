import hashlib,json
import numpy as np
import pandas as pd
import pytest
from src.market import load_ticks,complete_m1_bars,build_decisions
from src.settlement import Policy,reference_outcomes,trade_payoff,robust_trade_bounds
from src.dukascopy import decode_bi5
import lzma,struct,datetime as dt


def data(times, mids=None):
    if mids is None:mids=[1.10000]*len(times)
    d=pd.DataFrame({'timestamp_utc':pd.to_datetime(times,utc=True),'bid':np.asarray(mids)-.00005,'ask':np.asarray(mids)+.00005})
    d['mid']=(d.bid+d.ask)/2
    d['spread_pips']=(d.ask-d.bid)/.0001
    return d


def decisions(at):return pd.DataFrame({'decision_utc':pd.to_datetime([at],utc=True)})


def test_entry_and_expiry_are_true_300s():
    ticks=data(['2025-01-02T12:00:00Z','2025-01-02T12:00:04Z','2025-01-02T12:05:04Z'],[1.1,1.101,1.102])
    out=reference_outcomes(ticks,decisions('2025-01-02T12:00:00Z'),Policy())
    assert len(out)==1
    assert (out.settle_utc[0]-out.entry_utc[0]).total_seconds()==300
    assert out.entry_mid[0]==pytest.approx(1.101)
    assert out.reference_move_pips[0]==pytest.approx(10)


def test_missing_tick_not_backfilled():
    ticks=data(['2025-01-02T12:00:00Z','2025-01-02T12:00:04Z','2025-01-02T12:05:11Z'])
    assert reference_outcomes(ticks,decisions('2025-01-02T12:00:00Z'),Policy()).empty


def test_no_future_quote_at_entry():
    ticks=data(['2025-01-02T12:00:01Z','2025-01-02T12:05:01Z'])
    row=reference_outcomes(ticks,decisions('2025-01-02T12:00:00Z'))
    assert row.entry_utc.iloc[0].second==1


def test_inference_available_time_anchor():
    t=data(['2025-01-02T12:00:04Z','2025-01-02T12:00:08Z','2025-01-02T12:05:08Z'])
    d=decisions('2025-01-02T12:00:00Z')
    d['available_at_utc']=pd.to_datetime(['2025-01-02T12:00:06Z'],utc=True)
    row=reference_outcomes(t,d)
    assert row.entry_utc.iloc[0].second==8


def test_stale_model_output_fails_closed():
    t=data(['2025-01-02T12:01:01Z','2025-01-02T12:06:01Z'])
    d=decisions('2025-01-02T12:00:00Z')
    d['available_at_utc']=pd.to_datetime(['2025-01-02T12:01:00Z'],utc=True)
    assert reference_outcomes(t,d).empty


def test_model_timestamp_before_decision_rejected():
    t=data(['2025-01-02T12:00:04Z','2025-01-02T12:05:04Z'])
    d=decisions('2025-01-02T12:00:00Z')
    d['available_at_utc']=pd.to_datetime(['2025-01-02T11:59:59Z'],utc=True)
    assert reference_outcomes(t,d).empty


def test_spread_spike_rejects():
    t=data(['2025-01-02T12:00:04Z','2025-01-02T12:05:04Z'])
    t.loc[0,'ask']=t.loc[0,'bid']+.001
    assert reference_outcomes(t,decisions('2025-01-02T12:00:00Z')).empty


def test_tie_loss_and_refund():
    assert trade_payoff('CALL','TIE',.8,'refund')==0
    assert trade_payoff('CALL','TIE',.8,'loss')==-1
    assert trade_payoff('WAIT','UP',.8,'loss')!=trade_payoff('WAIT','UP',.8,'loss')


def test_call_put_returns():
    assert trade_payoff('CALL','UP',.8,'loss')==.8
    assert trade_payoff('CALL','DOWN',.8,'loss')==-1
    assert trade_payoff('PUT','DOWN',.8,'loss')==.8
    assert trade_payoff('PUT','UP',.8,'loss')==-1


def test_uncertainty_bounds():
    p=Policy(uncertainty_pips=.3)
    assert robust_trade_bounds('CALL',.5,p)==(.8,.8)
    assert robust_trade_bounds('CALL',-.5,p)==(-1,-1)
    assert robust_trade_bounds('CALL',.1,p)==(-1,.8)
    assert robust_trade_bounds('PUT',-.5,p)==(.8,.8)
    assert robust_trade_bounds('PUT',.1,p)==(-1,.8)


def test_no_fill_missing_bar():
    date=pd.to_datetime(['2025-01-02T12:00:00Z','2025-01-02T12:02:00Z'],utc=True)
    m=complete_m1_bars(data(date))
    assert pd.isna(m.loc['2025-01-02T12:01:00Z','close'])
    assert len(build_decisions(m))==0


def test_current_bar_leakage():
    # All ticks belonging to 12:00 are visible to a decision at 12:01, not at 12:00.
    times=pd.date_range('2025-01-02T12:00:00Z', periods=22*12, freq='5s')
    prices=np.arange(len(times))*.000001+1.1
    m=complete_m1_bars(data(times,prices))
    decisions=build_decisions(m)
    assert decisions.decision_utc.min()>=pd.Timestamp('2025-01-02T12:21:00Z')


def test_invalid_quotes_csv_rejected(tmp_path):
    csv=tmp_path/'x.csv'
    pd.DataFrame({'timestamp_utc':['2025-01-02T00:00:00Z','2025-01-02T00:00:01Z'],
             'bid':[1.2,1.3],'ask':[1.1,1.4]}).to_csv(csv,index=False)
    with pytest.raises(ValueError,match='crossed'):load_ticks(csv)


def test_utc_required(tmp_path):
    csv=tmp_path/'x.csv'
    pd.DataFrame({'timestamp_utc':['2025-01-02 00:00:00','2025-01-02 00:00:01'],
             'bid':[1.1,1.1],'ask':[1.101,1.102]}).to_csv(csv,index=False)
    with pytest.raises(ValueError,match='UTC'):load_ticks(csv)


def test_strict_timestamp_order(tmp_path):
    csv=tmp_path/'x.csv'
    pd.DataFrame({'timestamp_utc':['2025-01-02T00:00:01Z','2025-01-02T00:00:01Z'],
             'bid':[1.1,1.1],'ask':[1.101,1.102]}).to_csv(csv,index=False)
    with pytest.raises(ValueError,match='increasing'):load_ticks(csv)


def test_manifest_hash(tmp_path):
    csv=tmp_path/'x.csv'
    pd.DataFrame({'timestamp_utc':['2025-01-02T00:00:00Z','2025-01-02T00:00:01Z'],
             'bid':[1.1,1.1],'ask':[1.101,1.102]}).to_csv(csv,index=False)
    manifest={'dataset_kind':'real','instrument':'EURUSD','source':'test','retrieved_utc':'2025-01-01T00:00:00Z',
        'use_rights_note':'owned','timezone':'UTC','pricing':'bid_ask','source_file_sha256':'wrong'}
    mf=tmp_path/'manifest.json';mf.write_text(json.dumps(manifest))
    with pytest.raises(ValueError,match='SHA256'):load_ticks(csv,mf)


def test_bi5_decoder_month_day_and_prices():
    raw=struct.pack('>IIIff',1500,108005,108000,1.,2.)+struct.pack('>IIIff',2000,108006,108001,1.,2.)
    ticks,s=decode_bi5(lzma.compress(raw),dt.date(2024,1,15))
    assert len(ticks)==2
    assert ticks.bid.iloc[0]==pytest.approx(1.08000)
    assert ticks.ask.iloc[0]==pytest.approx(1.08005)
    assert ticks.timestamp_utc.iloc[0]==pd.Timestamp('2024-01-15T00:00:01.500Z')


def test_bi5_corrupt_rejected():
    with pytest.raises(ValueError):decode_bi5(b'garbage',dt.date(2024,1,15))


def test_policy_limits():
    with pytest.raises(ValueError):Policy(expiry_seconds=301)
    with pytest.raises(ValueError):Policy(payout=0)
    with pytest.raises(ValueError):Policy(uncertainty_pips=-1)
