import pandas as pd
import pytest
from src.benchmark import distinct_days_frame,_nonoverlap,_metrics,_score_rows,_logistic
from src.settlement import Policy


def test_distinct_days_requires_five():
    t=pd.DataFrame({'decision_utc':pd.to_datetime(['2025-01-01T00:00Z','2025-01-02T00:00Z'],utc=True)})
    with pytest.raises(ValueError):distinct_days_frame(t)


def test_nonoverlap_positions():
    x=pd.DataFrame({'entry_utc':pd.to_datetime(['2025-01-01T10:00Z','2025-01-01T10:01Z','2025-01-01T10:05Z'],utc=True),
                    'settle_utc':pd.to_datetime(['2025-01-01T10:05Z','2025-01-01T10:06Z','2025-01-01T10:10Z'],utc=True),
                    'signal':['CALL','PUT','CALL']})
    assert len(_nonoverlap(x))==2


def test_wait_model_zero_bets():
    d=pd.DataFrame({'momentum_5_pips':[-2,2,0]})
    z=_score_rows(d,Policy(),1,'no_trade')
    assert list(z.signal)==['WAIT']*3


def test_momentum_rule():
    d=pd.DataFrame({'momentum_5_pips':[-2,2,0]})
    z=_score_rows(d,Policy(),1,'momentum5')
    assert list(z.signal)==['PUT','CALL','WAIT']


def test_logistic_too_few_refuses():
    d=pd.DataFrame({'reference_direction':['UP']*20})
    assert _logistic(d,d)[0]==['WAIT']*len(d)


def test_empty_metrics_not_positive():
    m=_metrics(pd.DataFrame(),Policy())
    assert m['trades']==0 and m['roi_per_stake_percent'] is None
