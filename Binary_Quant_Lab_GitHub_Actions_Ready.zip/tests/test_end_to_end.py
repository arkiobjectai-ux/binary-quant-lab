import hashlib,json
from pathlib import Path
import pandas as pd
import pytest
from src.make_synthetic import make
from src.benchmark import evaluate

@pytest.fixture(scope='module')
def generated(tmp_path_factory):
    p=tmp_path_factory.mktemp('ticks')/'synth.csv'
    make(p,daily_hours=2)
    return p

def test_full_pipeline_has_no_market_claims(generated,tmp_path):
    r=evaluate(generated,str(generated)+'.manifest.json',tmp_path/'out')
    assert r['market_evidence'] is False
    assert r['broker_settlement_verified'] is False
    assert r['experiment_proves_profitable_strategy'] is False
    assert r['split']['min_training_settlement_before_validation'] is True
    assert r['stress_scenario_count']==90
    assert (tmp_path/'out'/'reference_trade_trials.csv').exists()

def test_relabeling_synthetic_as_real_does_not_certify_provenance(generated,tmp_path):
    m=json.loads(Path(str(generated)+'.manifest.json').read_text())
    m['dataset_kind']='real';m['source']='Unverified self-declared market data'
    new=tmp_path/'claimed.json';new.write_text(json.dumps(m))
    r=evaluate(generated,new,tmp_path/'out')
    assert r['data_declared_real'] is True
    assert r['market_evidence'] is False
    assert r['provenance_independently_audited'] is False

def test_external_future_inference_timestamp_rejected(generated,tmp_path):
    f=tmp_path/'predict.csv'
    pd.DataFrame([{'decision_utc':'2025-02-14T09:30:00Z','available_at_utc':'2025-02-14T09:30:31Z',
                   'model_name':'Kronos-base-unverified','signal':'CALL'}]).to_csv(f,index=False)
    with pytest.raises(ValueError,match='valid time window'):
        evaluate(generated,str(generated)+'.manifest.json',tmp_path/'out',external_forecasts=f)
