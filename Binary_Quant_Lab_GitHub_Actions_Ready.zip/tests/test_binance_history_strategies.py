from __future__ import annotations
import csv
import hashlib
import io
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED

import pandas as pd
import pytest

from src.binance_history import (archive_locator, verify_checksum,parse_archive,
                                 convert_archive, _timestamp_ms,_timestamp_iso)
from src.binance_strategies import generate_baselines, validate_bars, split_report

START=1790812800000  # 2026-10-01 00:00:00Z


def _make_archive(n=100,kind='klines',base=START):
    symbol='BTCUSDT';filename=f'{symbol}-1m-2026-10-01.zip' if kind=='klines' else f'{symbol}-aggTrades-2026-10-01.zip'
    b=io.BytesIO()
    with ZipFile(b,'w',ZIP_DEFLATED) as z:
        text=io.StringIO();w=csv.writer(text)
        if kind=='klines':
            for i in range(n):
                t=(base+i*60_000)*1000 # microsecond Spot archives 2025+
                p=100+(.02*i)
                w.writerow([t,p,p+.4,p-.4,p+.03,3,t+60_000_000-1,300,5,1,100,0])
        else:
            for i in range(n):
                t=(base+i*1000)*1000 + (i%997)
                w.writerow([i+1,100+.01*i,1,1000+i,1000+i,t,'False','True'])
        z.writestr(filename.replace('.zip','.csv'),text.getvalue())
    blob=b.getvalue()
    checksum=f'{hashlib.sha256(blob).hexdigest()}  {filename}\n'
    return filename,blob,checksum


def test_archive_urls_and_microseconds():
    a=archive_locator('btcusdt','klines',month='2026-10')
    assert a['url']=='https://data.binance.vision/data/spot/monthly/klines/BTCUSDT/1m/BTCUSDT-1m-2026-10.zip'
    b=archive_locator('ethusdt','aggTrades',day='2026-10-01')
    assert b['url']=='https://data.binance.vision/data/spot/daily/aggTrades/ETHUSDT/ETHUSDT-aggTrades-2026-10-01.zip'
    assert _timestamp_ms(str(START*1000+444))==START
    assert _timestamp_iso(str(START*1000+444)).endswith('00.000444Z')
    with pytest.raises(ValueError): archive_locator('BTCUSDT','klines',day='2026-02-30')
    with pytest.raises(ValueError): archive_locator('EUR/USD','klines',month='2026-10')
    with pytest.raises(ValueError): archive_locator('BTCUSDT','trades',month='2026-10')


def test_archive_checksum_and_closed_m1(tmp_path):
    name,blob,checksum=_make_archive()
    assert verify_checksum(blob,checksum,name)==hashlib.sha256(blob).hexdigest()
    with pytest.raises(ValueError,match='SHA256'): verify_checksum(blob,checksum.replace('a','0',1),name)
    data=parse_archive(blob,symbol='BTCUSDT',kind='klines',filename=name)
    assert len(data)==100
    assert data.close_at_utc.iloc[0] == pd.Timestamp(START+60000,unit='ms',tz='UTC').isoformat().replace('+00:00','Z')
    z=tmp_path/name;z.write_bytes(blob);c=tmp_path/(name+'.CHECKSUM');c.write_text(checksum)
    path,manifest=convert_archive('BTCUSDT','klines',day='2026-10-01',zip_path=z,checksum_path=c,out_dir=tmp_path/'output')
    assert path.exists() and manifest['archive_sha256_verified'] is True
    assert len(pd.read_csv(path))==100
    with pytest.raises(ValueError,match='requires official'):
        convert_archive('BTCUSDT','klines',day='2026-10-01',zip_path=z,out_dir=tmp_path/'invalid')


def test_aggtrade_archive_micro_precision_and_id_gap():
    name,blob,_=_make_archive(n=320,kind='aggTrades')
    data=parse_archive(blob,symbol='BTCUSDT',kind='aggTrades',filename=name)
    assert len(data)==320
    assert data.agg_id.diff().dropna().eq(1).all()
    assert '.000001Z' in data.timestamp_utc.iloc[1]
    assert data.price_kind.eq('last_trade_proxy').all()


def test_bad_kline_gap_is_rejected():
    name,blob,_=_make_archive()
    with ZipFile(io.BytesIO(blob)) as zin:
        member=zin.namelist()[0];lines=zin.read(member).decode().splitlines()
    bad=io.BytesIO()
    with ZipFile(bad,'w') as zout:zout.writestr(member,'\n'.join(lines[:9]+lines[10:]))
    with pytest.raises(ValueError,match='Gap'):
        parse_archive(bad.getvalue(),symbol='BTCUSDT',kind='klines',filename=name)


def test_strategies_past_only_and_three_models():
    name,blob,_=_make_archive(n=150)
    bars=parse_archive(blob,symbol='BTCUSDT',kind='klines',filename=name)
    signals=generate_baselines(bars)
    assert signals.model_name.nunique()==3
    assert signals.expiry_seconds.eq(300).all()
    assert set(signals.signal.unique())<= {'WAIT','CALL','PUT'}
    assert (pd.to_datetime(signals.available_at_utc,utc=True)>pd.to_datetime(signals.decision_utc,utc=True)).all()
    modified=bars.copy();modified.loc[140,'close']=103.1
    before=generate_baselines(bars);after=generate_baselines(modified)
    cutoff=str(bars.close_at_utc.iloc[139])
    assert before[before.decision_utc<=cutoff].signal.tolist()==after[after.decision_utc<=cutoff].signal.tolist()
    bad=bars.drop(index=[3]).reset_index(drop=True)
    with pytest.raises(ValueError,match='Non-consecutive'):validate_bars(bad)


def test_split_report_simple():
    rows=[]
    for model in ('a','b'):
        for i in range(40):
            stamp=pd.Timestamp(START+i*60000,unit='ms',tz='UTC').isoformat().replace('+00:00','Z')
            won=i%3!=0
            rows.append({'decision_utc':stamp,'model_name':model,'signal':'CALL','status':'PROXY_ONLY',
                         'proxy_result':'WIN' if won else 'LOSS','net_return_per_unit':.8 if won else -1})
    report=split_report(pd.DataFrame(rows))
    assert len(report['performance_rows'])==6
    assert abs(report['breakeven_win_rate']-1/1.8)<1e-12
    assert report['broker_settlement_verified'] is False


def test_end_to_end_strategy_cli_with_synthetic_aggtrade_proxy(tmp_path):
    from src.binance_strategies import main as research_main
    from src.binance_public import utc_iso_ms
    name,blob,_=_make_archive(n=100)
    bars=parse_archive(blob,symbol='BTCUSDT',kind='klines',filename=name)
    bar_csv=tmp_path/'SYNTHETIC_m1.csv';bars.to_csv(bar_csv,index=False)
    ticks=[]
    for i in range(102*60):
        ticks.append({'agg_id':i+1,'timestamp_utc':utc_iso_ms(START+i*1000),
                      'price':100+i*.00012,'quantity':1,'symbol':'BTCUSDT',
                      'price_kind':'last_trade_proxy'})
    ticks_file=tmp_path/'SYNTHETIC_trades.csv';pd.DataFrame(ticks).to_csv(ticks_file,index=False)
    out=tmp_path/'out'
    research_main(['--bars',str(bar_csv),'--aggtrades',str(ticks_file),'--out',str(out)])
    import json
    report=json.loads((out/'research_report.json').read_text())
    assert report['status']=='completed_proxy_only'
    assert report['broker_settlement_verified'] is False
    assert set(x['model_name'] for x in report['performance_rows'])=={
        'mom5_z1p2','meanrev20_z1p6','breakout20_prevhi_lo'}
    assert (out/'proxy_trades.csv').exists()
    assert report['proxy_summary']['usable_proxy_outcomes']>0
