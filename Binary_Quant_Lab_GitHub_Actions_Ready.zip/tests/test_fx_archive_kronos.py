import io, lzma, zipfile, struct
import numpy as np
import pandas as pd
import pytest
from src.fx_archive import decode_member, decode_archives
from src.kronos_fx import sample_asof, eligible_samples, replay_forecast


def raw_record(ms=250,ask=116184,bid=116181):
    return struct.pack('>IIIff',ms,ask,bid,1.0,1.0)


def test_decode_hourly_archive_and_empty_hour(tmp_path):
    a=tmp_path/'a.zip'
    with zipfile.ZipFile(a,'w') as z:
        z.writestr('EURUSD/20260901/00h_ticks.bi5',lzma.compress(raw_record(250)+raw_record(750)))
        z.writestr('EURUSD/20260901/01h_ticks.bi5',b'')
    report=decode_archives([a],tmp_path/'fx.csv')
    assert report['raw_tick_count']==2
    assert report['distinct_hours']==1
    assert report['empty_hourly_members']==1
    assert report['provenance_independently_verified'] is False
    df=pd.read_csv(tmp_path/'fx.csv')
    assert df.bid.iloc[0]==1.16181 and df.ask.iloc[0]==1.16184
    assert df.timestamp_utc.iloc[0]=='2026-09-01T00:00:00.250000Z'


def test_hour_cannot_be_assumed_daily():
    with pytest.raises(ValueError,match='hour-relative'):
        decode_member(lzma.compress(raw_record(3600001)), '20260901', 0)


def make_bars(n=400):
    idx=pd.date_range('2026-09-01',periods=n,freq='min',tz='UTC')
    close=np.linspace(1.1,1.2,n)
    b=pd.DataFrame({'open':close,'high':close+0.00005,'low':close-0.00005,
        'close':close,'count':np.ones(n), 'close_at_utc':idx+pd.Timedelta(minutes=1),
        'last_tick_time':idx+pd.Timedelta(seconds=59)},index=idx)
    return b


def test_asof_never_reads_future_values():
    b=make_bars(400)
    s1=sample_asof(b,300,context=256)
    b.iloc[301:,b.columns.get_loc('close')]=9999.0
    s2=sample_asof(b,300,context=256)
    assert s1['historical'].equals(s2['historical'])
    assert s1['future_clock_only'] and s1['decision_utc']==b.index[300]+pd.Timedelta(minutes=1)
    assert len(s1['y_timestamp'])==5
    assert s1['y_timestamp'].iloc[-1]==(b.index[300]+pd.Timedelta(minutes=5)).tz_localize(None)


def test_missing_minute_rejects_sample():
    b=make_bars(400)
    b.iloc[240,b.columns.get_loc('count')]=0
    assert sample_asof(b,300,context=256) is None


def test_replay_stub_not_claiming_real_kronos():
    class FakePredictor:
        def predict(self, **kwargs):
            assert len(kwargs['df'])==32 and len(kwargs['y_timestamp'])==5
            return pd.DataFrame({'close':[1.10]*5})
    b=make_bars(401)
    res,meta=replay_forecast(b,FakePredictor(),checkpoint='base',context=32,
         stride=1,max_samples=1,holdout_from='2026-09-01T00:33:00Z')
    assert meta['checkpoint']=='NeoQuasar/Kronos-base'
    assert meta['broker_settlement_verified'] is False
    assert res.availability_mode.iloc[0]=='HISTORICAL_REPLAY_NOT_REALTIME'

def test_broker_audit_rejects_otc(tmp_path):
    from src.fx_broker_audit import compare
    b=tmp_path/'b.csv';r=tmp_path/'r.csv'
    pd.DataFrame([{'contract_id':'1','model':'m','decision_utc':'2026-09-01T00:00:00Z',
       'symbol':'EURUSD','market_type':'OTC','quote_unit':'USD_PER_EUR',
       'broker_entry_utc':'2026-09-01T00:00:01Z','broker_settle_utc':'2026-09-01T00:05:01Z',
       'broker_entry_quote':1.1,'broker_settle_quote':1.2,'broker_payout':0.8}]).to_csv(b,index=False)
    pd.DataFrame([{'model':'m','decision_utc':'2026-09-01T00:00:00Z','entry_utc':'2026-09-01T00:00:01Z',
       'settle_utc':'2026-09-01T00:05:01Z','entry_mid':1.1,'settle_mid':1.2,
       'reference_direction':'UP','signal':'CALL'}]).to_csv(r,index=False)
    with pytest.raises(ValueError,match='OTC'):
        compare(r,b,tmp_path/'o.csv')
