import pandas as pd
import pytest
from src.broker_compare import audit
from src.stress import stress_grid


def test_broker_quote_mismatch_detected(tmp_path):
    ref=pd.DataFrame([{'model':'momentum5','decision_utc':'2025-02-14T12:00:00Z',
     'entry_utc':'2025-02-14T12:00:05Z','settle_utc':'2025-02-14T12:05:05Z',
     'entry_mid':1.10000,'settle_mid':1.10010,'reference_direction':'UP','signal':'CALL'}])
    br=pd.DataFrame([{'model':'momentum5','decision_utc':'2025-02-14T12:00:00Z',
     'broker_entry_utc':'2025-02-14T12:00:08Z','broker_settle_utc':'2025-02-14T12:05:08Z',
     'broker_entry_quote':1.10015,'broker_settle_quote':1.10007,'broker_payout':.8}])
    r=tmp_path/'ref.csv';b=tmp_path/'br.csv';ref.to_csv(r,index=False);br.to_csv(b,index=False)
    res=audit(r,b,tmp_path/'out.csv')
    assert res['broker_direction_mismatches']==1
    assert res['mean_abs_entry_price_delta_pips']==pytest.approx(1.5)
    assert res['mean_abs_settle_clock_delta_s']==3


def test_broker_duplicate_records_rejected(tmp_path):
    ref=pd.DataFrame([{'model':'a','decision_utc':'2025-02-14T12:00:00Z',
     'entry_utc':'2025-02-14T12:00:05Z','settle_utc':'2025-02-14T12:05:05Z',
     'entry_mid':1.1,'settle_mid':1.2,'reference_direction':'UP','signal':'CALL'}])
    br=pd.DataFrame([{'model':'a','decision_utc':'2025-02-14T12:00:00Z',
     'broker_entry_utc':'2025-02-14T12:00:06Z','broker_settle_utc':'2025-02-14T12:05:06Z',
     'broker_entry_quote':1.1,'broker_settle_quote':1.2,'broker_payout':.8}]*2)
    r=tmp_path/'ref.csv';b=tmp_path/'br.csv';ref.to_csv(r,index=False);br.to_csv(b,index=False)
    with pytest.raises(ValueError,match='Duplicate'):audit(r,b,tmp_path/'out.csv')


def test_stress_avoids_changing_signals():
    ticks=pd.DataFrame({'timestamp_utc':pd.to_datetime(['2025-02-14T12:00:01Z','2025-02-14T12:00:05Z',
      '2025-02-14T12:05:01Z','2025-02-14T12:05:05Z'],utc=True),
      'bid':[1.1,1.1,1.1001,1.1002],'ask':[1.1001,1.1001,1.1002,1.1003]})
    d=pd.DataFrame({'decision_utc':pd.to_datetime(['2025-02-14T12:00:00Z'],utc=True)})
    signals=pd.DataFrame({'decision_utc':d.decision_utc,'signal':['CALL']})
    t=stress_grid(ticks,d,{'x':signals},latencies=(1,5),payouts=(.7,.8),quote_uncertainties=(.2,))
    assert len(t)==4
    assert list(signals.signal)==['CALL']
