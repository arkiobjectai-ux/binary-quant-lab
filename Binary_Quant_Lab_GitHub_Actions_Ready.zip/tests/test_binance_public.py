from __future__ import annotations
import json
import pandas as pd
import pytest
from src.binance_public import fetch_closed_m1, export_dataset, momentum_baseline, validate_klines, fetch_aggtrades, parse_utc
from src.binance_audit import audit_crypto
from src.binance_shadow import simulate_300s

M=60_000
START=1_800_000_000_000 # UTC min boundary


def row(t,price):
    return [t,str(price),str(price+2),str(price-2),str(price+1),"9",t+M-1,"900",10,"0","0","0"]


class Fake:
    def __init__(self,bars,clock):self.bars=bars;self.clock=clock
    def get(self,path,**kwargs):
        if path=="/api/v3/time":return {"serverTime":self.clock}
        if path=="/api/v3/exchangeInfo":return {"symbols":[{"symbol":kwargs["symbol"],"baseAsset":"BTC","quoteAsset":"USDT","status":"TRADING"}]}
        if path=="/api/v3/klines":
            return [x for x in self.bars if kwargs["startTime"]<=x[0]<=kwargs["endTime"]][:kwargs["limit"]]
        raise AssertionError(path)


def make_bars(n=40):
    return [row(START+i*M,100+i) for i in range(n)]


def test_public_closed_m1_and_kronos_export(tmp_path):
    f=Fake(make_bars(),START+40*M+59_000)
    bars,meta,clock=fetch_closed_m1(f,"BTCUSDT",40)
    assert len(bars)==40
    assert bars.close_at_utc.iloc[-1]==pd.Timestamp(START+40*M,unit="ms",tz="UTC").isoformat().replace("+00:00","Z")
    assert meta["is_forex_reference"] is False
    manifest=export_dataset(bars,meta,clock,tmp_path)
    assert manifest["broker_settlement_verified"] is False
    assert manifest["kronos_base_executed"] is False
    assert len(pd.read_csv(tmp_path/"illustrative_baseline_signals.csv"))==20
    k=pd.read_csv(tmp_path/"kronos_ohlcv.csv")
    assert list(k.columns)==["timestamps","open","high","low","close","volume","amount"]
    assert len(k)==40
    assert all(pd.to_datetime(bars.close_at_utc,utc=True)>pd.to_datetime(bars.open_time_utc,utc=True))


def test_refuse_open_last_candle():
    # Current candle begins at t=39m but server now=39m+2 seconds; only 39 bars are closed.
    f=Fake(make_bars(), START+39*M+2000)
    x,_,_=fetch_closed_m1(f,"BTCUSDT",39)
    assert len(x)==39
    assert pd.Timestamp(x.open_time_utc.iloc[-1]).value // 10**6 ==START+38*M


def test_no_missing_minute_or_bad_ohlc():
    f=Fake(make_bars()[:5]+make_bars()[6:], START+40*M)
    with pytest.raises(ValueError,match="Gap|unexpected"):
        fetch_closed_m1(f,"BTCUSDT",40)
    bad=make_bars()
    bad[3][2]="1" # bad high
    with pytest.raises(ValueError,match="OHLC"):
        validate_klines(bad,"BTCUSDT",START,START+40*M)


def test_baseline_only_past_data():
    b,_,_=fetch_closed_m1(Fake(make_bars(), START+40*M),"BTCUSDT",40)
    d1=momentum_baseline(b)
    altered=b.copy();altered.loc[39,"close"]=1_000_000
    d2=momentum_baseline(altered)
    assert d1.signal.iloc[:19].tolist()==d2.signal.iloc[:19].tolist()
    assert (pd.to_datetime(d1.available_at_utc,utc=True)>pd.to_datetime(d1.decision_utc,utc=True)).all()


def test_aggtrades_and_broker_audit_same_symbol(tmp_path):
    anchor=1_800_000_000_000
    times=[anchor+1000*i for i in range(620)]
    raw=[{"a":i+1,"p":str(100+i/1000),"q":".1","T":t} for i,t in enumerate(times)]
    class FakeTrades:
        def get(self,path,**kwargs):
            if path=="/api/v3/exchangeInfo":return {"symbols":[{"symbol":"BTCUSDT","baseAsset":"BTC","quoteAsset":"USDT","status":"TRADING"}]}
            if path=="/api/v3/aggTrades":return raw
            raise AssertionError(path)
    agg,_=fetch_aggtrades(FakeTrades(),"BTCUSDT",anchor,anchor+619_000)
    assert len(agg)==620
    tr_path=tmp_path/"agg.csv";agg.to_csv(tr_path,index=False)
    broker=pd.DataFrame([{"contract_id":"a1","symbol":"BTCUSDT",
        "broker_entry_utc":pd.Timestamp(anchor+10_000,unit="ms",tz="UTC").isoformat(),
        "broker_settle_utc":pd.Timestamp(anchor+310_000,unit="ms",tz="UTC").isoformat(),
        "broker_entry_quote":100.01,"broker_settle_quote":99.9,"broker_payout":0.8}])
    br=tmp_path/"broker.csv";broker.to_csv(br,index=False)
    result=audit_crypto(br,tr_path,tmp_path/"audit.csv",symbol="BTCUSDT")
    assert result["matched"]==1
    assert result["direction_mismatch_count"]==1
    assert result["broker_authenticity_verified"] is False
    with pytest.raises(ValueError,match="symbol"):
        audit_crypto(br,tr_path,tmp_path/"bad.csv",symbol="ETHUSDT")
    with pytest.raises(ValueError,match="forex"):
        audit_crypto(br,tr_path,tmp_path/"bad.csv",symbol="EURUSD")


def test_shadow_sim_no_orders(tmp_path):
    anchor=1_800_000_000_000
    data=pd.DataFrame({"agg_id":range(1,1000),
         "timestamp_utc":[pd.Timestamp(anchor+i*1000,unit="ms",tz="UTC").isoformat() for i in range(999)],
         "price":[100+i/1000 for i in range(999)],"symbol":["BTCUSDT"]*999,
         "price_kind":["last_trade_proxy"]*999})
    tp=tmp_path/"trades.csv";data.to_csv(tp,index=False)
    start=pd.Timestamp(anchor+50_000,unit="ms",tz="UTC").isoformat()
    available=pd.Timestamp(anchor+51_000,unit="ms",tz="UTC").isoformat()
    sig=pd.DataFrame([{"decision_utc":start,"available_at_utc":available,
             "model_name":"baseline","signal":"CALL","source_symbol":"BTCUSDT","expiry_seconds":300}])
    sp=tmp_path/"signals.csv";sig.to_csv(sp,index=False)
    result=simulate_300s(sp,tp,"BTCUSDT",tmp_path/"shadow.csv")
    assert result["usable_proxy_outcomes"]==1
    assert result["broker_outcomes_verified"] is False
    assert result["proxy_win_rate"]==1.0


def test_time_and_aggtrade_gaps():
    with pytest.raises(ValueError,match="UTC"):
        parse_utc("2026-11-10T10:00:00")
    with pytest.raises(ValueError,match="1 hour"):
        fetch_aggtrades(None,"BTCUSDT",0,3_600_001)


def test_watcher_journal_stale_and_dedup(tmp_path):
    from src.binance_watch import run_once
    f=Fake(make_bars(),START+40*M+3_000)
    p=tmp_path/"journal.jsonl"
    record=run_once(f,"BTCUSDT",p,lookback_minutes=40,observed_ms=START+40*M+4_000)
    assert record["status"]=="READY_BASELINE_ONLY"
    assert record["available_at_utc"]==record["observed_at_utc"]
    assert record["broker_settlement_verified"] is False
    dup=run_once(f,"BTCUSDT",p,lookback_minutes=40,observed_ms=START+40*M+4_000)
    assert dup["status"]=="DUPLICATE_SKIPPED"
    assert len(p.read_text().splitlines())==1
    f2=Fake(make_bars(),START+40*M+26_000)
    q=run_once(f2,"BTCUSDT",tmp_path/"stale.jsonl",lookback_minutes=40,
               observed_ms=START+40*M+26_000)
    assert q["status"]=="STALE_FAIL_CLOSED" and q["signal"]=="WAIT"
    with pytest.raises(ValueError,match="FAIL CLOSED"):
        run_once(f,"BTCUSDT",tmp_path/"clock.jsonl",lookback_minutes=40,
                 observed_ms=START+40*M+80_000)
