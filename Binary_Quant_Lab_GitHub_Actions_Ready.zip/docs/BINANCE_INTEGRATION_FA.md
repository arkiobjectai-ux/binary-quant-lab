# Binary Quant Lab v0.5 — اتصال عمومی Binance Spot و ممیزی قیمت ۳۰۰ثانیه‌ای

**حوزه:** صرفاً پژوهش آفلاین و داده عمومی. هیچ سفارش واقعی یا دمو، ورود به حساب، کلید API، اتصال غیرمجاز Pocket Option یا دورزدن کنترل دسترسی وجود ندارد.

## تصمیم معماری

شاخه **اصلی فارکس** همان EUR/USD غیر OTC با Tick Bid/Ask، کندل M1، محاسبه سیگنال پس از بسته‌شدن کندل و تسویه ۳۰۰ ثانیه‌ای است (`src/market.py`, `src/settlement.py`, `src/broker_compare.py`). این شاخه تغییر داده نشده است.

شاخه **Binance Spot** برای آزمون مستقل نمادهای معامله‌شده در Binance (مثلاً BTCUSDT) ساخته شده است. `EURUSDT` (اگر در بایننس موجود باشد) رابطه یورو و تتر در یک صرافی است، نه قیمت EUR/USD فارکس و نه داده تسویه در Pocket Option. نمادهایی که base/quote دقیقاً یکی نیستند **نباید** در ممیزی تسویه مقایسه شوند. داده‌های OTC را هم‌ارز بازار واقعی نگیرید.

## مسیر داده

```text
GET /api/v3/time + /api/v3/exchangeInfo
       -> GET /api/v3/klines 1m
       -> حذف کندل باز (با ساعت سرور Binance)
       -> بررسی پیوستگی، قیمت، UTC و حذف نکردن silent gaps
       -> binance_m1_closed.csv + kronos_ohlcv.csv + SHA256 manifest
       -> نمونه Baseline momentum-5 (نه Kronos) => CALL / PUT / WAIT
       -> با داده تاریخی aggTrades: شبیه‌سازی قیمت آخرین معامله 300 ثانیه بعد
       -> در صورت صادرات مجاز همان نماد از بروکر: ممیزی اختلاف نرخ/زمان/جهت
```

**توجه:** Aggregated trades داده Bid/Ask نیست. close کندل، قیمت دقیق سر لحظه تسویه نیست. موتور فارکس v0.4 عمداً از این فایل‌ها تغذیه نمی‌شود؛ ابزارهای crypto جدا هستند.

## نصب و دریافت کندل‌های بسته‌شده واقعی

با Python 3.10+ و دسترسی مجاز به اینترنت از پوشه ریشه پروژه:

```bash
python -m pip install -r requirements.txt
python -m pytest -q
python -m src.binance_public --symbol BTCUSDT --minutes 720 --out data/binance_btcusdt
```

خروجی:

- `data/binance_btcusdt/binance_m1_closed.csv` — UTC، فقط M1 بسته‌شده، OHLCV قیمت معاملات Binance Spot؛ شامل زمان باز و زمان دسترسی پس از بستن
- `data/binance_btcusdt/kronos_ohlcv.csv` — ستون‌های `timestamps,open,high,low,close,volume,amount`؛ **خود checkpoint Kronos هنوز اجرا نشده** و باید با ورودی نسخه مورد استفاده آن تطبیق داده شود
- `data/binance_btcusdt/illustrative_baseline_signals.csv` — خروجی نمونه CALL/PUT/WAIT، بدون کالیبراسیون
- `data/binance_btcusdt/binance_manifest.json` — زمان سرور، منبع، پنجره، شناسه نماد، hash، محدودیت‌ها و پرچم `broker_settlement_verified=false`

برای baseline، `available_at_utc` از پایان M1 با فرض تأخیر مشخص ساخته می‌شود؛ این **تأخیر واقعی inference اندازه‌گیری‌شده نیست**. برای آزمایش Kronos-base باید زمان واقعی آماده‌شدن پاسخ مدل از لاگ ثبت شود. زمان `timestamps` در `kronos_ohlcv.csv`، زمان شروع کندل است؛ داده تا **پایان کندل** در دسترس نیست.

### جمع‌آوری معاملات تجمیع‌شده و آزمون ۳۰۰ثانیه‌ای

برای یک پنجره **تا یک ساعت** با زمان UTC صریح، مثال:

```bash
python -m src.binance_public --symbol BTCUSDT --minutes 720 \
  --out data/binance_btcusdt \
  --aggtrades-from-utc 2026-11-09T09:00:00Z \
  --aggtrades-to-utc 2026-11-09T09:20:00Z
```

`binance_aggtrades.csv` تنها در صورت دریافت کامل صفحات و پیوستگی شناسه‌های معاملات ذخیره می‌شود. `max-pages` محدود است تا مجموعه ناقص ناخواسته به‌عنوان داده صحیح منتشر نشود. اگر پنجره خیلی پرتراکم باشد، به بازه‌های کوچک‌تر تقسیم شود.

```bash
python -m src.binance_shadow \
  --signals data/binance_btcusdt/illustrative_baseline_signals.csv \
  --aggtrades data/binance_btcusdt/binance_aggtrades.csv \
  --symbol BTCUSDT --out outputs/crypto_shadow.csv \
  --delay-ms 1000 --max-lag-ms 2000 --uncertainty-bps 1.0 --payout 0.80
```

اگر سیگنال‌ها و پنجره تیک زمانی هم‌پوشانی نداشته باشند، برای آنها نتیجه معتبر صادر نمی‌شود. **برای backtest واقعی باید تاریخچه تصمیم‌ها و تیک‌های یکسان، در مجموعه‌های زمانی مستقل و با افق پوشش کافی جمع شود.** از خروجی این ابزار نمی‌توان بازده Pocket Option را استخراج کرد.

## ممیزی قیمت بروکر — تنها اگر دقیقاً همان جفت ارز/واحد باشد

ورودی دستی یا صادرات مجاز بروکر با *quote همان pair*:

```csv
contract_id,symbol,broker_entry_utc,broker_settle_utc,broker_entry_quote,broker_settle_quote,broker_payout
```

مثلاً اگر هر دو منبع واقعاً **BTC/USDT** و قیمت به USDT per BTC دارند، داده می‌تواند قابل مقایسه باشد؛ اگر بروکر **BTC/USD** را نشان می‌دهد، آن را `BTCUSDT` ننامید. وجود یک دارایی دقیقاً هم‌نام و با همان واحد در Pocket Option در این پروژه تأیید نشده است. برای EUR/USD واقعی، ممیزی صرفاً از مسیر FX پروژه v0.4 با داده FX انجام شود.

```bash
python -m src.binance_audit \
  --broker exports/authorized_same_pair_broker.csv \
  --aggtrades data/binance_btcusdt/binance_aggtrades.csv \
  --symbol BTCUSDT \
  --out outputs/crypto_broker_audit.csv
```

شاخص‌ها: تعداد نمونه‌های قابل تطبیق، تأخیر اولین trade پس از ورود/انقضا، اختلاف قیمت ورود/تسویه به basis point، موارد اختلاف جهت، موقعیت‌های نزدیک صفر، تعداد unmatched. **کاربر باید اصالت و واحد قیمت صادرات بروکر را تأیید کند**. این ابزار ادعای تأیید استقلال قیمت بروکر ندارد.

## اختلاف ساختاری که نباید فراموش شود

1. **دارایی یکسان نیست:** EUR/USD فارکس ≠ Binance EUR/USDT؛ Pocket Option OTC هم قیمت بازار مستقل نیست.
2. **قیمت یکسان نیست:** Binance Spot آخرین معامله را می‌دهد، Pocket Option قیمت مورد استفاده خود در قرارداد؛ نوع قیمت، Bid/Ask و اسپرد می‌توانند متفاوت باشند.
3. **زمان یکسان نیست:** سیگنال پس از بسته‌شدن کندل، آماده‌سازی مدل، ارسال/اجرای سفارش و زمان ۳۰۰ ثانیه از لحظه ورود بروکر تفاوت دارند. کلاک‌ها باید UTC و دقیق باشند.
4. **نرخ پرداخت متفاوت است:** payout باید برای هر قرارداد از خروجی بروکر ثبت شود؛ ثابت ۸۰٪ تنها فرض آزمایش است. نرخ برد سربه‌سر برای payout ۰٫۸ برابر `1/(1+.8)=55.56%` قبل از موارد خاص است.
5. **کیفیت برچسب متفاوت است:** نزدیک تساوی، اختلاف کوچک قیمت یا چند صدم ثانیه ممکن است جهت را تغییر دهد؛ نتیجه باید `UNCERTAIN` یا `UNMATCHED` ثبت شود.
6. **تعهد حقوقی:** تصمیم ۲۰۱۹ FIN-FSA فنلاند، بازاریابی، توزیع و فروش باینری آپشن به مشتریان خرد را (با استثناهای مشخص در متن تصمیم) ممنوع می‌کند؛ این پروژه سفارش‌گذار نیست.

## وضعیت راستی‌آزمایی در زمان بسته‌بندی

- دسترسی خواندنی به Binance از connector ChatGPT تأیید شد؛ چند کندل اخیر `BTCUSDT` بازیابی شدند.
- اجرای واقعی دانلودر در محیط ساخت فایل به‌علت نبود دسترسی خروجی اینترنت قابل انجام نبود؛ **هیچ داده تاریخی تازه‌ای در آرشیو به‌عنوان دانلودشده ادعا نشده است**.
- تست‌های واحد، شبیه‌سازی زمان‌بندی و جلوگیری از اختلاط نمادها آفلاین اجرا شده‌اند.
- در این مرحله هیچ داده تسویه مجاز و احرازاصالت‌شده از Pocket Option در دسترس نیست؛ نمی‌توان نرخ اختلاف واقعی را اندازه‌گیری کرد.
- Kronos-base و Kronos-small در این افزونه اجرا نشده‌اند؛ تنها ساختار تغذیه و baseline آزمایشی فراهم است.

## منابع

- Binance Spot General REST API: https://developers.binance.com/en/docs/products/spot/rest-api
- Binance public data-only API: https://data-api.binance.vision
- Pocket Option Public Offer (قیمت منبع بروکر): https://pocketoption.com/en/public-offer/
- ESMA درباره محدودیت‌های ملی باینری: https://www.esma.europa.eu/press-news/esma-news/esma-ceases-renewal-product-intervention-measure-relating-binary-options
- FIN-FSA Finland binary options decision: https://www.finanssivalvonta.fi/globalassets/en/publications/public-notices/decision_bo_19082019.pdf

## نسخه نمونه polling برای وصل‌شدن به سیستم تحلیل

برای اجرای **یک نوبت** دریافت تازه‌ترین M1 و ثبت سیگنال آزمایشی در دفترچه بدون اتصال معاملاتی:

```bash
python -m src.binance_watch --symbol BTCUSDT --cycles 1 --out outputs/binance_signal_journal.jsonl
```

برای اجرا به‌صورت یک فرایند باز در دستگاه خودتان (با توقف `Ctrl+C`):

```bash
python -m src.binance_watch --symbol BTCUSDT --cycles 0 --poll-seconds 15
```

خروجی JSONL رکوردها شامل `decision_utc`, `observed_at_utc`, `available_at_utc`, `signal`, `age_ms`, `source_bar_end_utc`, `status` است. بعد از ری‌استارت، تصمیم تکراری دوباره ثبت نمی‌شود (در صورت ثبت آخرین رکورد همان نماد). اگر ساعت سرور/میزبان اختلاف زیاد داشته باشد، داده غیرقابل اعتماد باشد یا سیگنال دیر برسد، سیگنال معاملاتی صادر نمی‌شود؛ در حالت دیرکرد، `WAIT` به همراه `STALE_FAIL_CLOSED` ثبت می‌شود. **Polling یک نمونه پژوهشی است، نه تضمین تأخیر ثابت یا فید سطح تولید.**
