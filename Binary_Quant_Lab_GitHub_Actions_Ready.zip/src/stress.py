"""Sensitivity analysis for precomputed reference predictions, with no hindsight retuning."""
from __future__ import annotations
from dataclasses import replace
import numpy as np
import pandas as pd
from .settlement import Policy,reference_outcomes
from .benchmark import _nonoverlap,_metrics


def stress_grid(ticks, hold, signal_panels, *, payouts=(.70,.80,.90),
                latencies=(1.0,5.0), quote_uncertainties=(.2,.5,1.0), maxlag=5):
    """Change settlement assumptions AFTER signals; don't refit or choose best.
    signal_panels: dict[str, pd.DataFrame] with decision_utc and signal.
    """
    output=[]
    for latency in latencies:
        refpolicy=Policy(decision_latency_seconds=latency,max_entry_lag_seconds=maxlag,
                         max_exit_lag_seconds=maxlag)
        ref=reference_outcomes(ticks,hold[['decision_utc']],refpolicy)
        for name,pred in signal_panels.items():
            joined=ref.merge(pred[['decision_utc','signal']],on='decision_utc',validate='one_to_one',how='inner')
            traded=_nonoverlap(joined)
            for payout in payouts:
                for eps in quote_uncertainties:
                    policy=replace(refpolicy,payout=payout,uncertainty_pips=eps)
                    m=_metrics(traded,policy)
                    output.append({'model':name,'latency_seconds':latency,'payout':payout,
                       'quote_uncertainty_pips':eps,'trades':m['trades'],'winrate_percent':m['winrate_percent'],
                       'reference_roi_percent':m['roi_per_stake_percent'],
                       'worst_case_roi_percent':m['worst_case_roi_percent'],
                       'best_case_roi_percent':m['best_case_roi_percent']})
    return pd.DataFrame(output)
