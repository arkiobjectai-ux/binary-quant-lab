"""Compare independent reference tick trials to user-supplied broker export.

Offline review only. Broker CSV must come from authorized exports; never request
credentials, browser cookies or reverse-engineering access controls.
"""
from __future__ import annotations
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd


def audit(reference_csv,broker_csv,out_csv):
    ref=pd.read_csv(reference_csv)
    broker=pd.read_csv(broker_csv)
    mandatory=['model','decision_utc','broker_entry_utc','broker_settle_utc','broker_entry_quote',
                'broker_settle_quote','broker_payout']
    if any(k not in broker.columns for k in mandatory):
        raise ValueError('Missing broker columns: '+str(set(mandatory)-set(broker.columns)))
    if any(k not in ref.columns for k in ['model','decision_utc','entry_utc','settle_utc','entry_mid','settle_mid','reference_direction','signal']):
        raise ValueError('Missing reference columns')
    for d in (ref,broker):
        for c in ('decision_utc',):
            if not d[c].astype(str).str.endswith(('Z','+00:00')).all():raise ValueError('UTC timezone explicitly required')
            d[c]=pd.to_datetime(d[c],utc=True)
    for c in ('broker_entry_utc','broker_settle_utc'):
        if not broker[c].astype(str).str.endswith(('Z','+00:00')).all():raise ValueError('UTC timezone explicitly required')
        broker[c]=pd.to_datetime(broker[c],utc=True)
    for c in ('entry_utc','settle_utc'):ref[c]=pd.to_datetime(ref[c],utc=True)
    for c in ('broker_entry_quote','broker_settle_quote','broker_payout'):
        broker[c]=pd.to_numeric(broker[c],errors='raise')
    if ((broker.broker_entry_quote<=0)|(broker.broker_settle_quote<=0)|
        (broker.broker_payout<=0)|(broker.broker_payout>2)).any():raise ValueError('Invalid broker quote/payout')
    if broker.duplicated(['model','decision_utc']).any():raise ValueError('Duplicate broker row')
    x=ref.merge(broker,on=['model','decision_utc'],how='inner',validate='one_to_one')
    if x.empty:raise ValueError('No matched broker/reference trials')
    x['entry_delta_pips']=(x.broker_entry_quote-x.entry_mid)/.0001
    x['settle_delta_pips']=(x.broker_settle_quote-x.settle_mid)/.0001
    x['entry_time_delta_s']=(x.broker_entry_utc-x.entry_utc).dt.total_seconds()
    x['settle_time_delta_s']=(x.broker_settle_utc-x.settle_utc).dt.total_seconds()
    change=x.broker_settle_quote-x.broker_entry_quote
    x['broker_direction']=np.where(change>0,'UP',np.where(change<0,'DOWN','TIE'))
    x['direction_mismatch']=x.broker_direction!=x.reference_direction
    x.to_csv(out_csv,index=False)
    return {'matched_trials':int(len(x)), 'broker_direction_mismatches':int(x.direction_mismatch.sum()),
        'direction_mismatch_percent':round(100*x.direction_mismatch.mean(),3),
        'mean_abs_entry_price_delta_pips':round(x.entry_delta_pips.abs().mean(),4),
        'mean_abs_settle_price_delta_pips':round(x.settle_delta_pips.abs().mean(),4),
        'mean_abs_settle_clock_delta_s':round(x.settle_time_delta_s.abs().mean(),3),
        'unmatched_broker_rows':len(broker)-len(x),
        'warning':'Provided broker export not independently authenticated; exact contract clocks and broker pricing must be verified.'}

if __name__=='__main__':
    p=argparse.ArgumentParser(description='Compare authorized broker export to market reference')
    p.add_argument('--reference',required=True);p.add_argument('--broker',required=True)
    p.add_argument('--out',default='outputs/broker_comparison.csv')
    a=p.parse_args();print(json.dumps(audit(a.reference,a.broker,a.out),ensure_ascii=False,indent=2))
