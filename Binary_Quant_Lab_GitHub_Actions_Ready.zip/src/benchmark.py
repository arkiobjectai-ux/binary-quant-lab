"""Chronologically split EURUSD 300s reference binary benchmark, research-only.

No model or signal can be interpreted as financial advice, and output is never an
executable broker order. The dataset's 'real' declaration is not verification.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
from dataclasses import asdict,replace
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from .market import load_ticks, complete_m1_bars, build_decisions
from .settlement import Policy,reference_outcomes,trade_payoff,robust_trade_bounds

FEATURES=['momentum_1_pips','momentum_5_pips','momentum_15_pips','volatility20_pips','spread_pips']


def distinct_days_frame(d):
    days=sorted(d.decision_utc.dt.floor('D').unique())
    if len(days)<5:raise ValueError('Need >=5 distinct UTC market days for chronological train/validation/holdout')
    a=max(1,int(len(days)*.6));b=max(a+1,int(len(days)*.8))
    if b>=len(days):b=len(days)-1
    return days[a],days[b],{'train_days':a,'validation_days':b-a,'holdout_days':len(days)-b,
                             'validation_first_utc':str(days[a]),'holdout_first_utc':str(days[b])}


def _score_rows(d,policy,threshold_pips,model):
    x=d.copy()
    if model=='momentum5':
        q=x.momentum_5_pips.to_numpy()
        x['signal']=np.where(q>threshold_pips,'CALL',np.where(q < -threshold_pips,'PUT','WAIT'))
    elif model=='contrarian5':
        q=x.momentum_5_pips.to_numpy()
        x['signal']=np.where(q>threshold_pips,'PUT',np.where(q < -threshold_pips,'CALL','WAIT'))
    elif model=='always_call':x['signal']='CALL'
    elif model=='no_trade':x['signal']='WAIT'
    else:raise ValueError(model)
    return x


def _nonoverlap(x):
    """One open position at once for each model; sequential sorting.
    Skip signals whose entry occurs before prior settlement (not double-stake).
    """
    selected=[];last_end=pd.Timestamp.min.tz_localize('UTC')
    for i,r in x.sort_values('entry_utc').iterrows():
        if r.signal=='WAIT' or r.entry_utc<last_end:continue
        selected.append(i);last_end=r.settle_utc
    return x.loc[selected].copy()


def _metrics(trades,policy):
    if trades.empty: return {'trades':0,'wins':0,'losses':0,'ties':0,'winrate_percent':None,
                             'roi_per_stake_percent':None,'worst_case_roi_percent':None,
                             'best_case_roi_percent':None}
    vals=[];low=[];high=[];wins=0;loss=0;ties=0
    for t in trades.itertuples():
        v=trade_payoff(t.signal,t.reference_direction,policy.payout,policy.tie_policy)
        a,b=robust_trade_bounds(t.signal,t.reference_move_pips,policy)
        vals.append(v);low.append(a);high.append(b)
        wins+=int(v==policy.payout);loss+=int(v==-1);ties+=int(v==0)
    return {'trades':len(trades),'wins':wins,'losses':loss,'ties':ties,
       'winrate_percent':round(wins/len(trades)*100,3),
       'roi_per_stake_percent':round(float(np.mean(vals))*100,3),
       'worst_case_roi_percent':round(float(np.mean(low))*100,3),
       'best_case_roi_percent':round(float(np.mean(high))*100,3),
       'note':'Independent reference price and assumed payout ONLY; overlap removed; not real broker P&L'}


def _logistic(train,others,prob_edge=.12):
    # No tuning on holdout: pre-registered fixed .62/.38 thresholds.
    good=train.loc[train.reference_direction.ne('TIE')]
    if len(good)<150 or good.reference_direction.nunique()<2:return ['WAIT']*len(others),'not_fitted_insufficient_classes_or_samples'
    y=(good.reference_direction=='UP').astype(int)
    fit=Pipeline([('scale',StandardScaler()),('logit',LogisticRegression(max_iter=500,class_weight=None,random_state=31))])
    fit.fit(good[FEATURES],y)
    p=fit.predict_proba(others[FEATURES])[:,1]
    labels=np.where(p>=.5+prob_edge,'CALL',np.where(p<=.5-prob_edge,'PUT','WAIT'))
    return labels.tolist(),'raw_un calibrated_probabilities_not_trade_ready'.replace(' ','')


def evaluate(tick_csv,manifest,outdir,*,payout=0.8,delay=1.0,maxlag=5.0,uncertainty=.2,
             pip_threshold=1.5,tie_policy='loss',external_forecasts=None):
    ticks,provenance=load_ticks(tick_csv,manifest)
    policy=Policy(payout=payout,decision_latency_seconds=delay,max_entry_lag_seconds=maxlag,
                  max_exit_lag_seconds=maxlag,uncertainty_pips=uncertainty,tie_policy=tie_policy)
    bars=complete_m1_bars(ticks)
    decisions=build_decisions(bars)
    ref=reference_outcomes(ticks,decisions,policy)
    if len(ref)<150:raise ValueError('Need >=150 valid reference decision+settlement pairs (prefer months of data)')
    merged=decisions.merge(ref,on='decision_utc',how='inner',validate='one_to_one')
    validation_start,holdout_start,split_meta=distinct_days_frame(merged)
    # Training outcomes must have SETTLED by the first validation decision.
    train=merged.loc[(merged.decision_utc<validation_start)&(merged.settle_utc<validation_start)]
    val=merged.loc[(merged.decision_utc>=validation_start)&(merged.decision_utc<holdout_start)&(merged.settle_utc<holdout_start)]
    hold=merged.loc[merged.decision_utc>=holdout_start]
    if len(train)<150 or len(val)<30 or len(hold)<30:raise ValueError('Insufficient split after purging')
    out=Path(outdir);out.mkdir(parents=True,exist_ok=True)
    signals=[];summary={};trace=[];panels={}
    for model in ('no_trade','always_call','momentum5','contrarian5','logistic'):
        if model=='logistic':
            ls,status=_logistic(train,hold)
            evalrow=hold.copy();evalrow['signal']=ls
        else:
            status='pre_registered_rule_no_training'
            evalrow=_score_rows(hold,policy,pip_threshold,model)
        evalrow['model']=model
        panels[model]=evalrow[['decision_utc','signal']].copy()
        actions=_nonoverlap(evalrow)
        m=_metrics(actions,policy)
        m.update({'all_holdout_decisions':len(hold),'signal_before_nonoverlap':int((evalrow.signal!='WAIT').sum()),
                  'executed_nonoverlapping_reference_trials':len(actions), 'model_status':status,
                  'daily_block_independence_not_established':True})
        summary[model]=m
        if len(actions):
            for r in actions.itertuples():
                low,high=robust_trade_bounds(r.signal,r.reference_move_pips,policy)
                trace.append({'model':model,'decision_utc':r.decision_utc.isoformat(),'entry_utc':r.entry_utc.isoformat(),
                     'settle_utc':r.settle_utc.isoformat(),'signal':r.signal,'entry_mid':float(r.entry_mid),
                     'settle_mid':float(r.settle_mid),'move_pips':float(r.reference_move_pips),
                     'reference_direction':r.reference_direction,'payout_return_unit':trade_payoff(r.signal,r.reference_direction,policy.payout,policy.tie_policy),
                     'worst_reference_return_unit':low,'best_reference_return_unit':high})
        signals.append(evalrow[['decision_utc','model','signal']])
    # Optional model predictions: explicit decision/availability clocks; no on-the-fly
    # inference from future candles permitted. Missing forecasts never inferred.
    if external_forecasts:
        ext=pd.read_csv(external_forecasts)
        required={'decision_utc','available_at_utc','model_name','signal'}
        if not required.issubset(ext.columns):raise ValueError('External file needs '+str(required))
        for col in ('decision_utc','available_at_utc'):
            if not ext[col].astype(str).str.endswith(('Z','+00:00')).all():raise ValueError('External times must be UTC explicit')
            ext[col]=pd.to_datetime(ext[col],utc=True)
        if ext.duplicated(['model_name','decision_utc']).any():raise ValueError('Duplicate external forecasts')
        if not ext.signal.isin(['CALL','PUT','WAIT']).all():raise ValueError('Unknown external signal')
        if not ((ext.available_at_utc>=ext.decision_utc)&
                (ext.available_at_utc-ext.decision_utc<=pd.Timedelta(seconds=policy.max_signal_age_seconds))).all():
            raise ValueError('External inference not available within valid time window')
        for name,g in ext.groupby('model_name'):
            match=hold[FEATURES+['decision_utc']].merge(g[['decision_utc','available_at_utc','signal']],on='decision_utc',how='inner',validate='one_to_one')
            if match.empty:continue
            external_ref=reference_outcomes(ticks,match,policy)
            tmp=match[['decision_utc','signal']].merge(external_ref,on='decision_utc',how='inner',validate='one_to_one')
            trades=_nonoverlap(tmp)
            summary['external:'+str(name)]={**_metrics(trades,policy),'model_status':'EXTERNAL_UNVERIFIED_FORECAST',
               'explicit_availability_checked':True,'forecasts_matched':len(tmp)}
            for r in trades.itertuples():
                low,high=robust_trade_bounds(r.signal,r.reference_move_pips,policy)
                trace.append({'model':'external:'+str(name),'decision_utc':r.decision_utc.isoformat(),
                'entry_utc':r.entry_utc.isoformat(),'settle_utc':r.settle_utc.isoformat(),
                'signal':r.signal,'entry_mid':r.entry_mid,'settle_mid':r.settle_mid,
                'move_pips':r.reference_move_pips,'reference_direction':r.reference_direction,
                'payout_return_unit':trade_payoff(r.signal,r.reference_direction,policy.payout,policy.tie_policy),
                'worst_reference_return_unit':low,'best_reference_return_unit':high})
    from .stress import stress_grid
    stress=stress_grid(ticks,hold,panels,maxlag=maxlag)
    stress.to_csv(out/'assumption_sensitivity.csv',index=False)
    pd.DataFrame(trace).to_csv(out/'reference_trade_trials.csv',index=False)
    pd.concat(signals,ignore_index=True).to_csv(out/'holdout_signals.csv',index=False)
    bars.to_csv(out/'derived_m1_bars.csv')
    report={'version':'0.4','experiment_type':'INDEPENDENT_FX_REFERENCE_BINARY_RESEARCH',
      'market_evidence':False,'data_declared_real':bool(provenance.get('is_real_data')), 'broker_settlement_verified':False,
      'all_real_money_trading_disabled':True,
      'experiment_proves_profitable_strategy':False,
      'provenance_independently_audited':False,
      'warning':'Real is declarative only; cannot verify real data origin or broker quote. No Kronos checkpoint evaluated.',
      'provenance':provenance,'policy':asdict(policy),
      'split':{**split_meta,'train_rows':len(train),'validation_rows':len(val),'holdout_rows':len(hold),
          'validation_used_for_model_selection':False,'holdout_used_for_tuning':False,
          'min_training_settlement_before_validation':bool((train.settle_utc<validation_start).all())},
      'tick_rows':len(ticks),'m1_bars_nonempty':int((bars['count']>0).sum()),
      'spread_pips_median':round(float(ticks.spread_pips.median()),4),
      'reference_pairs':len(merged),'assumed_payout_break_even_winrate_percent':round(100/(1+policy.payout),4),
      'metrics_reference_only':summary,'stress_scenario_count':len(stress),
      'restrictions':['no broker comparison','no external model weights','no live API','no payout schedule','no confidence intervals on correlated trials','not executable in Finland as binary product without legal verification']}
    (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    return report


def main():
    p=argparse.ArgumentParser(description='REFERENCE ONLY: Five-minute binary quant research with tick data')
    p.add_argument('--ticks',required=True);p.add_argument('--manifest',required=True)
    p.add_argument('--out',default='outputs/research')
    p.add_argument('--payout',type=float,default=.8);p.add_argument('--delay',type=float,default=1.0)
    p.add_argument('--max-lag',type=float,default=5.0);p.add_argument('--uncertainty-pips',type=float,default=.2)
    p.add_argument('--pip-threshold',type=float,default=1.5)
    p.add_argument('--tie-policy',choices=['loss','refund'],default='loss')
    p.add_argument('--external-forecasts')
    a=p.parse_args()
    res=evaluate(a.ticks,a.manifest,a.out,payout=a.payout,delay=a.delay,maxlag=a.max_lag,
       uncertainty=a.uncertainty_pips,pip_threshold=a.pip_threshold,tie_policy=a.tie_policy,
       external_forecasts=a.external_forecasts)
    print(json.dumps({'market_evidence':res['market_evidence'],
      'broker_verified':False,'training_test':res['split'],
      'reference_metrics':res['metrics_reference_only']},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
