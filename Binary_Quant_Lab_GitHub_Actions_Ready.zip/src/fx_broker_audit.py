"""Strict offline comparison of EUR/USD reference quotes to independently exported broker contracts.
No broker access or implicit broker-price verification. Invalid currency/OTC pairs fail closed.
"""
from __future__ import annotations
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd

REQUIRED={'contract_id','model','decision_utc','symbol','market_type','quote_unit',
          'broker_entry_utc','broker_settle_utc','broker_entry_quote','broker_settle_quote','broker_payout'}

def compare(reference_file,broker_file,out_file,max_entry_offset_seconds=10,max_settle_offset_seconds=10):
    ref=pd.read_csv(reference_file);broker=pd.read_csv(broker_file)
    miss=REQUIRED-set(broker.columns)
    if miss:raise ValueError('Broker CSV missing '+','.join(sorted(miss)))
    if broker.empty:raise ValueError('No broker contracts')
    if not broker.symbol.astype(str).str.upper().isin(['EURUSD','EUR/USD']).all():
        raise ValueError('EUR/USD FX only: EURUSDT and BTCUSDT cannot be used')
    if not (broker.market_type=='REGULAR_FOREX').all():
        raise ValueError('OTC/synthetic market is incompatible with independent EUR/USD reference')
    if not (broker.quote_unit=='USD_PER_EUR').all():
        raise ValueError('Broker quote unit must be explicitly USD_PER_EUR')
    if broker.contract_id.isna().any() or broker.contract_id.duplicated().any():raise ValueError('Broker contract IDs must be unique')
    if broker.duplicated(['model','decision_utc']).any():raise ValueError('Duplicate decision/model')
    required_ref={'model','decision_utc','entry_utc','settle_utc','entry_mid','settle_mid','reference_direction','signal'}
    if not required_ref.issubset(ref.columns):raise ValueError('Invalid reference trade file')
    if ref.duplicated(['model','decision_utc']).any():raise ValueError('Duplicate reference key')
    for d,cols in ((ref,['decision_utc','entry_utc','settle_utc']),
                   (broker,['decision_utc','broker_entry_utc','broker_settle_utc'])):
        for col in cols:
            if not d[col].astype(str).str.endswith(('Z','+00:00')).all():
                raise ValueError('All time stamps must explicitly be UTC')
            d[col]=pd.to_datetime(d[col],utc=True,errors='raise')
    for col in ('broker_entry_quote','broker_settle_quote','broker_payout'):
        broker[col]=pd.to_numeric(broker[col],errors='raise')
    if not np.isfinite(broker[['broker_entry_quote','broker_settle_quote','broker_payout']].to_numpy()).all():
        raise ValueError('Non-finite broker values')
    if ((broker.broker_entry_quote<=0)|(broker.broker_settle_quote<=0)|
        (broker.broker_payout<=0)|(broker.broker_payout>2)).any():raise ValueError('Bad prices or payout')
    durations=(broker.broker_settle_utc-broker.broker_entry_utc).dt.total_seconds()
    if not durations.between(297,303,inclusive='both').all():
        raise ValueError('Broker contract expiration is not 300 ± 3 seconds from broker entry')
    x=ref.merge(broker,on=['model','decision_utc'],how='inner',validate='one_to_one')
    if x.empty:raise ValueError('No matching contracts')
    x['entry_clock_offset_s']=(x.broker_entry_utc-x.entry_utc).dt.total_seconds()
    x['settle_clock_offset_s']=(x.broker_settle_utc-x.settle_utc).dt.total_seconds()
    x['entry_quote_delta_pips']=(x.broker_entry_quote-x.entry_mid)/0.0001
    x['settle_quote_delta_pips']=(x.broker_settle_quote-x.settle_mid)/0.0001
    delta=x.broker_settle_quote-x.broker_entry_quote
    x['broker_direction']=np.where(delta>0,'UP',np.where(delta<0,'DOWN','TIE'))
    x['reference_broker_direction_mismatch']=x.broker_direction!=x.reference_direction
    x['timing_matched']=x.entry_clock_offset_s.abs().le(max_entry_offset_seconds)&x.settle_clock_offset_s.abs().le(max_settle_offset_seconds)
    x['status']=np.where(x.timing_matched,'MATCHED_TIME_WINDOW','TIME_MISMATCH_EXCLUDED')
    out=Path(out_file);out.parent.mkdir(parents=True,exist_ok=True)
    x.to_csv(out,index=False)
    good=x[x.timing_matched]
    return {'broker_quotes_independently_authenticated':False,'matching_contract_id_required':True,
            'total_broker_rows':len(broker),'joined_contracts':len(x),'timing_valid_pairs':len(good),
            'unmatched_broker_rows':len(broker)-len(x),
            'excluded_time_mismatch':int((~x.timing_matched).sum()),
            'direction_mismatches_on_time_valid':int(good.reference_broker_direction_mismatch.sum()),
            'direction_mismatch_rate_percent':round(float(good.reference_broker_direction_mismatch.mean()*100),3) if len(good) else None,
            'mean_abs_entry_price_delta_pips':round(float(good.entry_quote_delta_pips.abs().mean()),4) if len(good) else None,
            'mean_abs_settle_price_delta_pips':round(float(good.settle_quote_delta_pips.abs().mean()),4) if len(good) else None,
            'note':'No automatically acquired broker data; all quote comparisons depend on separately sourced user-authorized export.'}

def main():
    p=argparse.ArgumentParser(description='Strict five-minute EURUSD regular-FX broker/independent-reference audit')
    p.add_argument('--reference',required=True);p.add_argument('--broker',required=True);p.add_argument('--out',required=True)
    a=p.parse_args()
    print(json.dumps(compare(a.reference,a.broker,a.out),indent=2))
if __name__=='__main__':main()
