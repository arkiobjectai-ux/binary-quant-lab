"""Optional public historical file importer (no account access, no scraping login).

Run externally only after checking Dukascopy data use/redistribution terms.
Ref: https://www.dukascopy.com/wiki/en/development/data-export/
Dukascopy daily .bi5: zero-based month, big-endian >IIIff, LZMA.
No downloader runs as part of tests or default analysis.
"""
from __future__ import annotations
import argparse,datetime as dt,hashlib,json,lzma,struct,urllib.error,urllib.request
from pathlib import Path
import numpy as np
import pandas as pd

REC=struct.Struct('>IIIff')
URL='https://datafeed.dukascopy.com/datafeed/EURUSD/{y}/{m:02d}/{d:02d}_ticks.bi5'

def decode_bi5(data:bytes, day:dt.date):
    try: raw=lzma.decompress(data)
    except lzma.LZMAError as e:raise ValueError('Bad LZMA stream') from e
    if len(raw)==0 or len(raw)%REC.size: raise ValueError('Bad record length')
    start=pd.Timestamp(day).tz_localize('UTC')
    rows=[]
    prev=-1
    for i in range(0,len(raw),REC.size):
        ms,ask,bid,av,bv=REC.unpack_from(raw,i)
        if not 0<=ms<86400000:raise ValueError('Timestamp outside day')
        if ms<prev:raise ValueError('Unsorted tick data')
        prev=ms
        bb=bid/100000.0;aa=ask/100000.0
        if not 0<bb<aa<10 or not np.isfinite([av,bv]).all():raise ValueError('Bad bid ask or volume')
        rows.append((start+pd.Timedelta(milliseconds=int(ms)),bb,aa))
    t=pd.DataFrame(rows,columns=['timestamp_utc','bid','ask'])
    # Multiple quotes can share one millisecond: keep last value for stable lookup,
    # document deduplication and never claim full unmodified tick feed.
    before=len(t)
    t=t.drop_duplicates('timestamp_utc',keep='last').reset_index(drop=True)
    return t,{'raw_tick_rows':before,'unique_timestamp_rows':len(t),'same_millisecond_updates_discarded':before-len(t)}


def download_public_days(start:str,end:str,output:str,max_days:int=7):
    a=dt.date.fromisoformat(start);b=dt.date.fromisoformat(end)
    if b<a or (b-a).days+1>max_days:raise ValueError('Limit date range; default max 7 days')
    out=Path(output);out.parent.mkdir(parents=True,exist_ok=True)
    chunks=[];files=[]
    for idx in range((b-a).days+1):
        day=a+dt.timedelta(days=idx)
        url=URL.format(y=day.year,m=day.month-1,d=day.day)
        req=urllib.request.Request(url,headers={'User-Agent':'BinaryQuantLab-Research/0.4'})
        try:
            with urllib.request.urlopen(req,timeout=25) as res: data=res.read(120*1024*1024+1)
            if len(data)>120*1024*1024:raise ValueError('Daily file over size limit')
        except urllib.error.HTTPError as e:
            files.append({'day':day.isoformat(),'url':url,'status':f'http_{e.code}'})
            continue
        sub,stats=decode_bi5(data,day)
        chunks.append(sub)
        files.append({'day':day.isoformat(),'url':url,'raw_bi5_sha256':hashlib.sha256(data).hexdigest(),
                      'status':'decoded',**stats})
    if not chunks:raise ValueError('No historical days downloaded. Nothing written')
    combined=pd.concat(chunks,ignore_index=True)
    combined['timestamp_utc']=combined.timestamp_utc.dt.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
    combined.to_csv(out,index=False,float_format='%.5f')
    return files


def main():
    ap=argparse.ArgumentParser(description='Optional public historical EURUSD ticks (no broker API)')
    ap.add_argument('--start',required=True);ap.add_argument('--end',required=True)
    ap.add_argument('--out',required=True);ap.add_argument('--rights-note',required=True)
    a=ap.parse_args()
    if not a.rights_note.strip() or a.rights_note.lower() in ('unknown','unverified'):
        raise SystemExit('Document permitted data use; no automatic assumption of rights')
    days=download_public_days(a.start,a.end,a.out)
    manifest={'dataset_kind':'real','instrument':'EURUSD','source':'Dukascopy public datafeed (independent market reference)',
      'retrieved_utc':dt.datetime.now(dt.timezone.utc).isoformat(), 'use_rights_note':a.rights_note,
      'timezone':'UTC','pricing':'bid_ask','source_file_sha256':hashlib.sha256(Path(a.out).read_bytes()).hexdigest(),
      'files':days,'independent_broker_settlement_verified':False}
    Path(str(a.out)+'.manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({'csv':a.out,'manifest':str(a.out)+'.manifest.json','decoded_days':sum(d['status']=='decoded' for d in days)},indent=2))
if __name__=='__main__':main()
