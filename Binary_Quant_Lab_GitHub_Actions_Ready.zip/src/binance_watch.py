"""Read-only minute polling and append-only shadow-signal journal.

No order execution; explicit fail-closed when feed stale, invalid or unavailable.
For actual Kronos inference, replace the baseline policy with a separately
verified worker and log actual model completion times.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import time
from .binance_public import PublicClient,fetch_closed_m1,momentum_baseline,utc_iso_ms,parse_utc


def _last_record(path: Path):
    if not path.exists() or path.stat().st_size==0:return None
    with path.open("rb") as f:
        f.seek(0,2);size=f.tell();n=min(size,8192);f.seek(-n,2)
        lines=f.read().splitlines()
    if not lines:return None
    try:return json.loads(lines[-1])
    except (UnicodeDecodeError,json.JSONDecodeError):
        raise ValueError("Corrupt last journal record; refuse duplicate-unsafe append")


def run_once(client, symbol:str,out_jsonl:str|Path,*,lookback_minutes:int=90,
             max_signal_age_ms:int=25_000, observed_ms:int|None=None):
    if lookback_minutes<30 or max_signal_age_ms<=0:raise ValueError("Invalid watch parameters")
    bars,meta,server_ms=fetch_closed_m1(client,symbol,lookback_minutes)
    clock=int(time.time()*1000) if observed_ms is None else int(observed_ms)
    if abs(clock-server_ms)>30_000:
        raise ValueError("Host clock mismatch or Binance server/data fetch stale; FAIL CLOSED")
    sig=momentum_baseline(bars,inference_latency_ms=0)
    d=sig.iloc[-1]
    decision=str(d.decision_utc)
    age=clock-parse_utc(decision)
    if age<0:
        raise ValueError("Decision closes in the future; FAIL CLOSED")
    record={"market":"BINANCE_SPOT","symbol":meta["symbol"],
        "decision_utc":decision,"observed_at_utc":utc_iso_ms(clock),
        "available_at_utc":utc_iso_ms(clock),
        "source_bar_end_utc":decision,"expiry_seconds":300,
        "model_name":str(d.model_name),"signal":str(d.signal) if age<=max_signal_age_ms else "WAIT",
        "source_signal":str(d.signal),"age_ms":age,
        "status":"READY_BASELINE_ONLY" if age<=max_signal_age_ms else "STALE_FAIL_CLOSED",
        "quote_basis":"Binance last traded price OHLCV, not broker quote",
        "broker_settlement_verified":False,"kronos_base_executed":False}
    path=Path(out_jsonl);path.parent.mkdir(parents=True,exist_ok=True)
    previous=_last_record(path)
    if previous and previous.get("decision_utc")==decision and previous.get("symbol")==meta["symbol"]:
        return {"status":"DUPLICATE_SKIPPED","decision_utc":decision}
    with path.open("a",encoding="utf-8") as f:f.write(json.dumps(record,ensure_ascii=False)+"\n")
    return record


def main(argv=None):
    p=argparse.ArgumentParser(description="Read-only Binance Spot 1m research journal; no orders")
    p.add_argument("--symbol",default="BTCUSDT")
    p.add_argument("--out",default="outputs/binance_signal_journal.jsonl")
    p.add_argument("--lookback",type=int,default=90)
    p.add_argument("--max-age-ms",type=int,default=25_000)
    p.add_argument("--cycles",type=int,default=1,help="1=one poll, 0=run until Ctrl+C")
    p.add_argument("--poll-seconds",type=int,default=15)
    a=p.parse_args(argv)
    if a.cycles<0 or a.poll_seconds<10:raise ValueError("Invalid cycles or poll interval")
    client=PublicClient()
    n=0
    while a.cycles==0 or n<a.cycles:
        n+=1
        try:
            report=run_once(client,a.symbol,a.out,lookback_minutes=a.lookback,max_signal_age_ms=a.max_age_ms)
            print(json.dumps(report,ensure_ascii=False,flush=True))
        except (ValueError,RuntimeError) as exc:
            print(json.dumps({"status":"FEED_FAILURE_NO_SIGNAL","message":str(exc)},ensure_ascii=False,flush=True))
            if a.cycles==1:raise SystemExit(2)
        if a.cycles==0 or n<a.cycles:time.sleep(a.poll_seconds)

if __name__=="__main__":main()
