"""Offline decoder for user-supplied, hourly Dukascopy-formatted EURUSD .bi5 ZIPs.

The filename is a claim, NOT independent source authentication. No broker account needed.
"""
from __future__ import annotations
import argparse, datetime as dt, hashlib, io, json, lzma, re, struct, zipfile
from pathlib import Path
import pandas as pd
import numpy as np

PATTERN = re.compile(r'^EURUSD/(\d{8})/(\d{2})h_ticks\.bi5$')
REC=struct.Struct('>IIIff')

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):
            h.update(block)
    return h.hexdigest()

def decode_member(payload, date_key, hour):
    if not 0<=hour<=23:raise ValueError('Invalid hour')
    date=dt.datetime.strptime(date_key,'%Y%m%d').replace(tzinfo=dt.timezone.utc)
    date+=dt.timedelta(hours=hour)
    data=lzma.decompress(payload)
    if not data or len(data)%REC.size:raise ValueError('Bad or empty hourly .bi5')
    rows=[];last_ms=-1
    for ms,ask_i,bid_i,av,bv in REC.iter_unpack(data):
        if not 0<=ms<3600000:raise ValueError('Not hour-relative timestamp')
        if ms<last_ms:raise ValueError('Unsorted records within hour')
        last_ms=ms
        ask=ask_i/1e5;bid=bid_i/1e5
        if not (0<bid<ask<10 and np.isfinite(av) and np.isfinite(bv) and av>=0 and bv>=0):
            raise ValueError('Invalid Bid/Ask or volume')
        rows.append((date+dt.timedelta(milliseconds=int(ms)),bid,ask))
    return rows

def decode_archives(paths,out_csv, rights_note='personal research on user-supplied archive'):
    paths=[Path(p) for p in paths]
    if not paths:raise ValueError('Need at least one archive')
    members={};archives=[]
    for p in paths:
        if not p.is_file():raise FileNotFoundError(p)
        with zipfile.ZipFile(p) as z:
            for member in z.namelist():
                m=PATTERN.fullmatch(member)
                if not m:raise ValueError('Unexpected archive entry '+member)
                key=(m.group(1),int(m.group(2)))
                if key in members:raise ValueError('Duplicate source hour '+str(key))
                members[key]=z.read(member)
        archives.append({'name':p.name,'sha256':sha256(p),'size_bytes':p.stat().st_size})
    rows=[];stats=[]
    for (day,hour),payload in sorted(members.items()):
        if not payload:
            stats.append({'date':day,'hour':hour,'ticks_raw':0,'status':'EMPTY_SOURCE_MEMBER',
                          'sha256_bi5':hashlib.sha256(payload).hexdigest()})
            continue
        r=decode_member(payload,day,hour)
        rows.extend(r)
        stats.append({'date':day,'hour':hour,'ticks_raw':len(r),'status':'DECODED',
                      'sha256_bi5':hashlib.sha256(payload).hexdigest()})
    if len(rows)<2:raise ValueError('Not enough ticks')
    df=pd.DataFrame(rows,columns=['timestamp_utc','bid','ask'])
    if not df.timestamp_utc.is_monotonic_increasing:raise ValueError('Out-of-order source data')
    duplicates=int(df.timestamp_utc.duplicated(keep='last').sum())
    df=df.drop_duplicates('timestamp_utc',keep='last')
    if not df.timestamp_utc.is_monotonic_increasing or df.timestamp_utc.duplicated().any():raise ValueError('Timestamp integrity failure')
    out=Path(out_csv);out.parent.mkdir(parents=True,exist_ok=True)
    df['timestamp_utc']=pd.to_datetime(df['timestamp_utc'],utc=True).dt.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
    df.to_csv(out,index=False,float_format='%.5f')
    manifest={
        'dataset_kind':'real','instrument':'EURUSD',
        'source':'User-supplied Dukascopy-formatted hourly .bi5 archives (attribution NOT independently verified)',
        'retrieved_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
        'use_rights_note':rights_note,'timezone':'UTC','pricing':'bid_ask',
        'source_file_sha256':sha256(out),'archive_files':archives,
        'source_members':stats,
        'raw_tick_count':sum(x['ticks_raw'] for x in stats),
        'unique_millisecond_count':len(df),
        'same_millisecond_updates_discarded':duplicates,
        'distinct_hours':sum(s['status']=='DECODED' for s in stats),
        'empty_hourly_members':sum(s['status']=='EMPTY_SOURCE_MEMBER' for s in stats),
        'distinct_calendar_days':int(pd.to_datetime(df.timestamp_utc).dt.floor('D').nunique()),
        'start_utc':df.timestamp_utc.iloc[0],
        'end_utc':df.timestamp_utc.iloc[-1],
        'provenance_independently_verified':False,
        'broker_settlement_verified':False,
        'hourly_members_missing_may_be_weekends_or_incomplete':True,
        'decoded_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
    }
    mpath=Path(str(out)+'.manifest.json')
    mpath.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    return manifest

def main():
    p=argparse.ArgumentParser(description='Offline decode archived hourly EURUSD bid/ask ZIP .bi5 data')
    p.add_argument('--archive',action='append',required=True,help='Repeat for multiple ZIPs')
    p.add_argument('--out',required=True)
    a=p.parse_args()
    m=decode_archives(a.archive,a.out)
    print(json.dumps({k:m[k] for k in ['raw_tick_count','unique_millisecond_count','same_millisecond_updates_discarded','distinct_hours','distinct_calendar_days','start_utc','end_utc','source_file_sha256']},indent=2))
if __name__=='__main__':main()
