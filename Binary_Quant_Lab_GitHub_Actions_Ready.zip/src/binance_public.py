"""Read-only Binance Spot public market data adapter; separate from EUR/USD FX pipeline.

No API keys, order routes, Pocket Option access, synthetic gap filling, or OTC proxies.
Use Binance server time when deciding whether an M1 candle has closed.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import pandas as pd
import numpy as np

BASE = "https://data-api.binance.vision"
M1_MS = 60_000
DOCS = "https://developers.binance.com/en/docs/products/spot/rest-api"


def utc_iso_ms(ms: int) -> str:
    return pd.Timestamp(int(ms), unit="ms", tz="UTC").isoformat().replace("+00:00", "Z")


def parse_utc(value: str) -> int:
    if not (value.endswith("Z") or value.endswith("+00:00")):
        raise ValueError("Explicit UTC time required (Z or +00:00)")
    t = pd.Timestamp(value)
    if t.tzinfo is None or t.utcoffset().total_seconds() != 0:
        raise ValueError("UTC required")
    return int(t.value // 1_000_000)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


class PublicClient:
    def __init__(self, base: str = BASE, timeout: float = 10.0):
        if base not in (BASE, "https://api.binance.com"):
            raise ValueError("Unexpected endpoint; only approved public Binance hosts")
        self.base, self.timeout = base, timeout

    def get(self, endpoint: str, **params):
        if endpoint not in ("/api/v3/time", "/api/v3/exchangeInfo", "/api/v3/klines", "/api/v3/aggTrades"):
            raise ValueError("Public market-data endpoints only")
        url = self.base + endpoint + ("?" + urlencode(params) if params else "")
        req = Request(url, headers={"User-Agent": "BinaryQuantLab-Research/0.5", "Accept": "application/json"})
        for attempt in range(3):
            try:
                with urlopen(req, timeout=self.timeout) as resp:
                    value = json.loads(resp.read())
                if isinstance(value, dict) and "code" in value and int(value["code"]) < 0:
                    raise ValueError(f"Binance public API: {value}")
                return value
            except HTTPError as e:
                if e.code not in (429, 500, 502, 503, 504) or attempt == 2:
                    raise RuntimeError(f"Binance HTTP {e.code}; check symbol, IP and rate limits") from e
                time.sleep(min(2 ** attempt, 2))
            except (URLError, TimeoutError) as e:
                if attempt == 2:
                    raise RuntimeError("Cannot reach Binance public endpoint") from e
                time.sleep(min(2 ** attempt, 2))
        raise RuntimeError("Unexpected Binance API failure")


def symbol_metadata(client: PublicClient, symbol: str) -> dict:
    symbol = symbol.upper().replace("/", "").strip()
    if not symbol.isalnum() or len(symbol) > 24:
        raise ValueError("Invalid symbol")
    value = client.get("/api/v3/exchangeInfo", symbol=symbol)
    found = value.get("symbols", [])
    if len(found) != 1 or found[0].get("symbol") != symbol:
        raise ValueError(f"No Binance Spot symbol {symbol}")
    m = found[0]
    if m.get("status") != "TRADING":
        raise ValueError(f"Binance Spot symbol not active: {symbol}")
    return {"symbol": symbol, "base_asset": m["baseAsset"], "quote_asset": m["quoteAsset"],
            "market": "BINANCE_SPOT", "is_forex_reference": False,
            "warning": "Binance Spot quotes are not EUR/USD FX nor broker settlement prices."}


def validate_klines(rows: list, symbol: str, start_ms: int, end_exclusive_ms: int) -> pd.DataFrame:
    fields = ["open_time_utc", "close_at_utc", "open", "high", "low", "close",
              "volume", "amount", "number_of_trades", "symbol"]
    output = []
    for r in rows:
        if len(r) < 11:
            raise ValueError("Malformed Binance kline")
        t = int(r[0]); close_ms = int(r[6]); o, h, l, c = map(float, r[1:5])
        vol, amount = float(r[5]), float(r[7]); count = int(r[8])
        if t % M1_MS or close_ms != t + M1_MS - 1:
            raise ValueError("Unexpected M1 kline timestamp semantics")
        if not all(map(math.isfinite, (o,h,l,c,vol,amount))) or min(o,h,l,c) <= 0:
            raise ValueError("Invalid OHLC price")
        if l > min(o,c) or h < max(o,c) or l>h or vol < 0 or amount<0 or count<0:
            raise ValueError("Invalid OHLC/volume")
        if not start_ms <= t < end_exclusive_ms:
            raise ValueError("Out-of-window Binance bar")
        output.append((utc_iso_ms(t),utc_iso_ms(t+M1_MS),o,h,l,c,vol,amount,count,symbol))
    df = pd.DataFrame(output, columns=fields)
    if df.empty:raise ValueError("No bars returned")
    times = pd.to_datetime(df.open_time_utc, utc=True).astype("int64") // 1_000_000
    diffs = np.diff(times.to_numpy())
    if times.iloc[0] != start_ms or times.iloc[-1] != end_exclusive_ms-M1_MS or not (diffs==M1_MS).all():
        raise ValueError("Gap, overlap, missing bar or unsupported symbol history. No forward fill allowed.")
    return df


def fetch_closed_m1(client: PublicClient, symbol: str, minutes: int, server_ms: int | None = None):
    if not (30 <= minutes <= 20_000):
        raise ValueError("minutes must be 30..20000")
    meta = symbol_metadata(client, symbol)
    timestamp_ms = int(client.get("/api/v3/time")["serverTime"]) if server_ms is None else int(server_ms)
    closed_until = timestamp_ms // M1_MS * M1_MS
    first_ms = closed_until - int(minutes)*M1_MS
    rows = []; cursor = first_ms
    while cursor < closed_until:
        take = min(1000, (closed_until - cursor)//M1_MS)
        batch = client.get("/api/v3/klines", symbol=meta["symbol"], interval="1m",
                           startTime=cursor, endTime=closed_until-1, limit=take)
        if not isinstance(batch, list) or not batch:
            raise ValueError("Missing Binance kline window; cannot silently fill")
        if int(batch[0][0]) != cursor:
            raise ValueError("Binance returned unexpected kline starting time")
        rows.extend(batch)
        nxt = int(batch[-1][0])+M1_MS
        if nxt<=cursor:raise ValueError("Pagination did not advance")
        cursor = nxt
    return validate_klines(rows,meta["symbol"],first_ms,closed_until), meta, timestamp_ms


def momentum_baseline(bars: pd.DataFrame, inference_latency_ms: int = 1000,
                      threshold: float = 1.2) -> pd.DataFrame:
    """Illustrative baseline; score is NOT a calibrated win probability.
    Uses closed bars only, emits no order execution and no model claims.
    """
    if not 0 <= inference_latency_ms <= 30_000 or threshold <= 0:
        raise ValueError("Invalid baseline configuration")
    close = bars.close.astype(float)
    ret = np.log(close).diff()
    momentum = np.log(close / close.shift(5))
    std = ret.rolling(20,min_periods=20).std()*np.sqrt(5)
    z = (momentum/std.replace(0,np.nan)).replace([np.inf, -np.inf],np.nan)
    decisions = []
    for idx in range(20, len(bars)):
        val = float(z.iloc[idx])
        if not np.isfinite(val):signal="WAIT"
        else:signal="CALL" if val >= threshold else "PUT" if val <= -threshold else "WAIT"
        closed = parse_utc(str(bars.close_at_utc.iloc[idx]))
        decisions.append({"decision_utc":utc_iso_ms(closed),
                          "available_at_utc":utc_iso_ms(closed+inference_latency_ms),
                          "model_name":"baseline_momentum5_UNCALIBRATED",
                          "signal":signal,"z_score":round(val,8) if np.isfinite(val) else "",
                          "source_symbol":str(bars.symbol.iloc[idx]),"expiry_seconds":300})
    return pd.DataFrame(decisions)


def validate_aggtrades(raw: list, symbol: str, start_ms: int, end_ms: int) -> pd.DataFrame:
    fields = ["agg_id","timestamp_utc","price","quantity","symbol","price_kind"]
    tuples=[]
    for row in raw:
        agg_id=int(row["a"]); timestamp_ms=int(row["T"])
        price=float(row["p"]); qty=float(row["q"])
        if not start_ms <= timestamp_ms <= end_ms: continue
        if not np.isfinite(price) or not np.isfinite(qty) or price<=0 or qty<=0:
            raise ValueError("Bad aggregate trade")
        tuples.append((agg_id,utc_iso_ms(timestamp_ms),price,qty,symbol,"last_trade_proxy"))
    df=pd.DataFrame(tuples,columns=fields)
    if df.empty:raise ValueError("No trades in requested range")
    ids=df.agg_id.to_numpy(); ts=pd.to_datetime(df.timestamp_utc,utc=True).astype("int64").to_numpy()
    if (np.diff(ids)!=1).any() or (np.diff(ts)<0).any():
        raise ValueError("Aggregated trade ID gap/overlap or non-monotonic timestamps")
    return df


def fetch_aggtrades(client: PublicClient, symbol: str, start_ms: int, end_ms: int, max_pages:int=150):
    if end_ms <= start_ms or end_ms-start_ms>3_600_000:
        raise ValueError("Require a positive window <=1 hour to cap API work")
    if not 1<=max_pages<=1000:raise ValueError("invalid max_pages")
    meta=symbol_metadata(client,symbol)
    received=[]; from_id=None; finished=False
    for page in range(max_pages):
        if from_id is None:
            batch=client.get("/api/v3/aggTrades",symbol=meta["symbol"],startTime=start_ms,endTime=end_ms,limit=1000)
        else:
            batch=client.get("/api/v3/aggTrades",symbol=meta["symbol"],fromId=from_id,limit=1000)
        if not isinstance(batch,list):raise ValueError("Malformed Binance trade response")
        if not batch:
            finished=True;break
        if from_id is not None and int(batch[0]["a"])!=from_id:
            raise ValueError("Missing aggregate trade IDs during pagination")
        if received and int(batch[0]["a"])!=int(received[-1]["a"])+1:
            raise ValueError("Discontinuous aggregate trades")
        for item in batch:
            if int(item["T"])>end_ms:
                finished=True;break
            if int(item["T"])>=start_ms:received.append(item)
        if finished or len(batch)<1000:
            finished=True;break
        from_id=int(batch[-1]["a"])+1
    if not finished:
        raise ValueError("Exceeded max_pages; INCOMPLETE historical trades cannot be used")
    return validate_aggtrades(received,meta["symbol"],start_ms,end_ms),meta


def export_dataset(bars:pd.DataFrame,meta:dict,server_ms:int,out_dir:Path,
                   latency_ms:int=1000,source:str=BASE):
    out_dir.mkdir(parents=True,exist_ok=True)
    p=out_dir/"binance_m1_closed.csv"; bars.to_csv(p,index=False)
    kronos=bars[["open_time_utc","open","high","low","close","volume","amount"]].copy()
    kronos=kronos.rename(columns={"open_time_utc":"timestamps"})
    kpath=out_dir/"kronos_ohlcv.csv"; kronos.to_csv(kpath,index=False)
    signal_path=out_dir/"illustrative_baseline_signals.csv"
    momentum_baseline(bars,latency_ms).to_csv(signal_path,index=False)
    manifest={"schema_version":1,"dataset_kind":"real_external_unverified",
              "market":"BINANCE_SPOT","symbol":meta["symbol"],
              "base_asset":meta["base_asset"],"quote_asset":meta["quote_asset"],
              "source":source,"server_time_utc":utc_iso_ms(server_ms),
              "retrieved_utc":pd.Timestamp.now(tz="UTC").isoformat(),
              "period_start_utc":bars.open_time_utc.iloc[0],"period_end_exclusive_utc":bars.close_at_utc.iloc[-1],
              "bar_interval":"1m","bars_count":len(bars),"expiry_seconds":300,
              "source_file_sha256":sha256(p),"kronos_file_sha256":sha256(kpath),
              "price_type":"exchange_trade_OHLCV_not_bid_ask",
              "broker_settlement_verified":False,"broker_data_available":False,
              "kronos_base_executed":False,"is_eurusd_forex":False,
              "restrictions":["No Pocket Option price verification", "No OTC price mapping",
                              "No cross-asset settlement inference", "No live orders", "Signals are uncalibrated baseline only"]}
    (out_dir/"binance_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    return manifest


def main(argv=None):
    p=argparse.ArgumentParser(description="Read-only Binance Spot feed, completed M1 candles and 300s research baseline")
    p.add_argument("--symbol",default="BTCUSDT")
    p.add_argument("--minutes",type=int,default=720)
    p.add_argument("--out",default="data/binance_btcusdt")
    p.add_argument("--inference-latency-ms",type=int,default=1000)
    p.add_argument("--aggtrades-from-utc",help="Explicit UTC start; optional historical trade audit window")
    p.add_argument("--aggtrades-to-utc",help="Explicit UTC end; optional; max span 1h")
    p.add_argument("--max-pages",type=int,default=150)
    a=p.parse_args(argv)
    client=PublicClient();bars,meta,clock=fetch_closed_m1(client,a.symbol,a.minutes)
    out=Path(a.out);report=export_dataset(bars,meta,clock,out,a.inference_latency_ms)
    if bool(a.aggtrades_from_utc) != bool(a.aggtrades_to_utc):
        raise ValueError("Both aggregate-trade window endpoints required")
    if a.aggtrades_from_utc:
        t,m=fetch_aggtrades(client,a.symbol,parse_utc(a.aggtrades_from_utc),parse_utc(a.aggtrades_to_utc),a.max_pages)
        path=out/"binance_aggtrades.csv";t.to_csv(path,index=False)
        report["aggtrades_file_sha256"]=sha256(path)
        report["aggtrades_count"]=len(t)
        (out/"binance_manifest.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=="__main__":main()
