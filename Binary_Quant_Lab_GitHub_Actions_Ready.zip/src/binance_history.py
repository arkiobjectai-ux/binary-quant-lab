"""Binance Spot public archive import; independent from FX & broker settlement.

Read-only, checksum-verified, no automatic missing-candle interpolation.
SPOT archives published from 2025-01-01 use MICROSECOND timestamps.
See https://github.com/binance/binance-public-data
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import re
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import urlopen, Request
from zipfile import ZipFile, BadZipFile

import pandas as pd
import numpy as np

from .binance_public import M1_MS, validate_klines, sha256, utc_iso_ms

BASE = 'https://data.binance.vision'
SYMBOL_PATTERN = re.compile(r'^[A-Z0-9]{5,20}$')
DAY_PATTERN = re.compile(r'^20\d{2}-(0[1-9]|1[0-2])-([0-2]\d|3[01])$')
MONTH_PATTERN = re.compile(r'^20\d{2}-(0[1-9]|1[0-2])$')
MAX_BYTES = 400_000_000  # explicit cap for archives; large high-volume symbols need partitioning
MAX_RECORDS = 2_000_000  # fail closed, not silent truncation


def archive_locator(symbol:str, kind:str, *, day:str|None=None, month:str|None=None):
    symbol = symbol.strip().upper()
    if not SYMBOL_PATTERN.fullmatch(symbol):raise ValueError('Invalid Spot symbol')
    if (day is None) == (month is None):raise ValueError('Exactly one of day/month required')
    if kind not in ('klines','aggTrades'):raise ValueError('Only public Spot klines / aggTrades')
    date = day if day is not None else month
    pat = DAY_PATTERN if day is not None else MONTH_PATTERN
    if not pat.fullmatch(date):raise ValueError('Invalid archive date')
    if day is not None:
        pd.Timestamp(day)  # reject 2026-02-30, not just regex
    if pd.Timestamp((day or month)+'-01' if month else day, tz='UTC') > pd.Timestamp.now(tz='UTC'):
        raise ValueError('No future archive date')
    period='daily' if day else 'monthly'
    folder=f'{symbol}/1m' if kind=='klines' else symbol
    name=f'{symbol}-1m-{date}.zip' if kind=='klines' else f'{symbol}-aggTrades-{date}.zip'
    rel=f'/data/spot/{period}/{kind}/{folder}/{name}'
    return {'symbol':symbol,'kind':kind,'period':date,'url':BASE+rel,'filename':name}


def _request_bytes(url:str, max_bytes=MAX_BYTES)->bytes:
    if not url.startswith(BASE+'/data/spot/'):
        raise ValueError('Only official Binance public Spot archives allowed')
    err=None
    for attempt in range(3):
        try:
            req=Request(url,headers={'User-Agent':'BinaryQuantLab-Research/0.7'})
            with urlopen(req,timeout=35) as response:
                chunks=[];total=0
                while chunk:=response.read(1<<20):
                    total+=len(chunk)
                    if total>max_bytes:raise ValueError('Archive exceeds configured size cap')
                    chunks.append(chunk)
            return b''.join(chunks)
        except HTTPError as e:
            if e.code==404:raise FileNotFoundError('Binance archive not yet published or absent') from e
            if e.code not in (429,500,502,503,504):raise
            err=e
        except (URLError,TimeoutError) as e:err=e
        if attempt<2:time.sleep(2**attempt)
    raise RuntimeError('Public Binance archive fetch failed') from err


def verify_checksum(blob:bytes, checksum_text:str, filename:str)->str:
    # Official .CHECKSUM contains sha256 and filename; disallow incorrect manifest names.
    lines=[x.strip() for x in checksum_text.splitlines() if x.strip()]
    matches=[]
    for ln in lines:
        m=re.fullmatch(r'([a-fA-F0-9]{64})\s+\*?([^/\\]+)',ln)
        if m and m.group(2)==filename:matches.append(m.group(1).lower())
    if len(matches)!=1:raise ValueError('Missing/ambiguous archive checksum for requested file')
    digest=hashlib.sha256(blob).hexdigest()
    if digest!=matches[0]:raise ValueError('Binance archive SHA256 mismatch')
    return digest


def _timestamp_ms(value:str)->int:
    s=str(value).strip()
    if not s.isdigit():raise ValueError('Expected integer epoch timestamp')
    t=int(s)
    # Spot public archive uses microseconds from January 2025 onwards.
    if 1_000_000_000_000_000 <= t < 10_000_000_000_000_000:
        return t//1000
    if 1_000_000_000_000 <= t < 10_000_000_000_000:
        return t
    raise ValueError('Unexpected timestamp epoch or precision')


def _timestamp_iso(value:str)->str:
    s=str(value).strip()
    if not s.isdigit():raise ValueError('Expected integer epoch timestamp')
    t=int(s)
    if 1_000_000_000_000_000 <=t<10_000_000_000_000_000:
        return pd.Timestamp(t,unit='us',tz='UTC').isoformat().replace('+00:00','Z')
    return utc_iso_ms(_timestamp_ms(s))


def _csv_reader(blob:bytes, expected_csv:str):
    try:
        z=ZipFile(io.BytesIO(blob))
    except BadZipFile as e:raise ValueError('Bad Binance archive ZIP') from e
    members=z.infolist()
    if len(members)!=1 or members[0].filename != expected_csv:
        z.close();raise ValueError('Unexpected ZIP member name or count')
    info=members[0]
    if info.file_size>MAX_BYTES*5:
        z.close();raise ValueError('Uncompressed ZIP payload too large')
    def run():
        try:
            with z, z.open(info) as stream, io.TextIOWrapper(stream,encoding='utf-8-sig',newline='') as text:
                for i,row in enumerate(csv.reader(text)):
                    if i>=MAX_RECORDS:raise ValueError('Too many rows: partition historical archive')
                    if not row:continue
                    yield row
        finally:z.close()
    return run()


def parse_archive(blob:bytes, *,symbol:str,kind:str,filename:str):
    expected=filename.removesuffix('.zip')+'.csv'
    if not filename.startswith(symbol+'-') or not filename.endswith('.zip'):
        raise ValueError('Incorrect archive filename or symbol')
    source=_csv_reader(blob,expected)
    if kind=='klines':
        raws=[]
        for row in source:
            if row[0].lower().strip() in ('open_time','open time'):continue
            if len(row)!=12:raise ValueError('Invalid archived kline schema')
            row=list(row);row[0]=_timestamp_ms(row[0]);row[6]=_timestamp_ms(row[6])
            raws.append(row)
        if not raws:raise ValueError('Empty kline archive')
        start=int(raws[0][0]);end=int(raws[-1][0])+M1_MS
        bars=validate_klines(raws,symbol,start,end)
        return bars
    if kind=='aggTrades':
        rows=[];previous_id=None;previous_ts=None
        for line in source:
            if line[0].lower().strip() in ('aggregate tradeid','agg_trade_id','aggtradeid'):continue
            if len(line)<6:raise ValueError('Invalid archived aggregate-trade schema')
            aid=int(line[0]);raw_ts=line[5];ms=_timestamp_ms(raw_ts)
            price=float(line[1]);qty=float(line[2])
            if not np.isfinite(price) or price<=0 or not np.isfinite(qty) or qty<=0:
                raise ValueError('Invalid trade price/quantity')
            if previous_id is not None and aid!=previous_id+1:raise ValueError('Aggregate trade ID gap')
            if previous_ts is not None and ms<previous_ts:raise ValueError('Trade timestamp reversed')
            previous_id=aid;previous_ts=ms
            rows.append((aid,_timestamp_iso(raw_ts),price,qty,symbol,'last_trade_proxy'))
        if not rows:raise ValueError('Empty trade archive')
        return pd.DataFrame(rows,columns=['agg_id','timestamp_utc','price','quantity','symbol','price_kind'])
    raise ValueError('Unsupported archive type')


def convert_archive(symbol:str,kind:str,*,day:str|None=None,month:str|None=None,
                    zip_path:str|Path|None=None,checksum_path:str|Path|None=None,out_dir:str|Path='data/binance_history'):
    loc=archive_locator(symbol,kind,day=day,month=month)
    if zip_path is None:
        blob=_request_bytes(loc['url'])
        checksum=_request_bytes(loc['url']+'.CHECKSUM',max_bytes=4096).decode('utf-8')
    else:
        if checksum_path is None:raise ValueError('Local ZIP requires official .CHECKSUM alongside it')
        blob=Path(zip_path).read_bytes()
        checksum=Path(checksum_path).read_text(encoding='utf-8')
    digest=verify_checksum(blob,checksum,loc['filename'])
    df=parse_archive(blob,symbol=loc['symbol'],kind=kind,filename=loc['filename'])
    out=Path(out_dir);out.mkdir(parents=True,exist_ok=True)
    output_name=f"{loc['symbol']}_{kind}_{loc['period']}.csv"
    path=out/output_name;df.to_csv(path,index=False)
    source_path=out/loc['filename'];source_path.write_bytes(blob)
    manifest={'schema_version':1,'source':'Binance Official Public Data Archive','url':loc['url'],
              'symbol':loc['symbol'],'market':'BINANCE_SPOT','kind':kind,'period':loc['period'],
              'archive_sha256_verified':True,'archive_sha256':digest,
              'csv_sha256':sha256(path),'record_count':len(df),
              'first_utc':str(df.open_time_utc.iloc[0] if kind=='klines' else df.timestamp_utc.iloc[0]),
              'last_utc':str(df.open_time_utc.iloc[-1] if kind=='klines' else df.timestamp_utc.iloc[-1]),
              'price_basis':'exchange_last_trade_proxy','broker_settlement_verified':False,
              'chronological_integrity_checked':True,'gap_filling':False,
              'notes':'Archive integrity does not imply Pocket Option quote or fill agreement.'}
    (out/f"{loc['symbol']}_{kind}_{loc['period']}.manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    return path,manifest


def main(argv=None):
    p=argparse.ArgumentParser(description='Checksum-verified Binance public Spot archive downloader / importer')
    p.add_argument('--symbol',default='BTCUSDT')
    p.add_argument('--kind',choices=['klines','aggTrades'],default='klines')
    group=p.add_mutually_exclusive_group(required=True)
    group.add_argument('--month');group.add_argument('--day')
    p.add_argument('--zip',dest='zip_path');p.add_argument('--checksum',dest='checksum_path')
    p.add_argument('--out',default='data/binance_history')
    a=p.parse_args(argv)
    path,report=convert_archive(a.symbol,a.kind,month=a.month,day=a.day,
                               zip_path=a.zip_path,checksum_path=a.checksum_path,out_dir=a.out)
    print(json.dumps({'output_csv':str(path),**report},indent=2,ensure_ascii=False))

if __name__=='__main__':main()
