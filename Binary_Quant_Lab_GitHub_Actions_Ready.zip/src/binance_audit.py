"""Offline 300-second Binance-trade-proxy vs authorized broker-quote audit.

Only compares the *same* base/quote pair and unit. Not applicable to EUR/USD FX,
EUR/USDT stablecoin-to-FX substitution, BTC/USD-to-BTC/USDT substitution, or OTC.
Broker quotes alone decide actual broker contract outcomes; no trade execution.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
from .binance_public import parse_utc, sha256

BROKER_FIELDS=("contract_id","symbol","broker_entry_utc","broker_settle_utc",
               "broker_entry_quote","broker_settle_quote","broker_payout")
TRADES_FIELDS=("agg_id","timestamp_utc","price","symbol","price_kind")


def _load_broker(path:Path, expected_symbol:str):
    df=pd.read_csv(path,dtype={"contract_id":str,"symbol":str})
    if not set(BROKER_FIELDS).issubset(df.columns):
        raise ValueError(f"Missing broker CSV fields {sorted(set(BROKER_FIELDS)-set(df.columns))}")
    if df.empty or df.contract_id.isna().any() or df.contract_id.duplicated().any():
        raise ValueError("Missing or duplicate contract IDs")
    if not df.symbol.eq(expected_symbol).all():
        raise ValueError("Broker and Binance exact base/quote symbol must match; no FX/OTC conversion")
    for col in ("broker_entry_quote","broker_settle_quote","broker_payout"):
        df[col]=pd.to_numeric(df[col],errors="raise")
    if not np.isfinite(df[["broker_entry_quote","broker_settle_quote","broker_payout"]].values).all():
        raise ValueError("Non-finite broker quote")
    if (df.broker_entry_quote<=0).any() or (df.broker_settle_quote<=0).any() or not df.broker_payout.between(.01,2).all():
        raise ValueError("Bad quote/payout")
    for col in ("broker_entry_utc","broker_settle_utc"):
        df[col]=pd.to_datetime(df[col].map(parse_utc),unit="ms",utc=True)
    duration=(df.broker_settle_utc-df.broker_entry_utc).dt.total_seconds()
    if not duration.between(299.0,301.0).all():
        raise ValueError("This audit requires 300s contracts (±1s recorded-clock tolerance)")
    return df


def _load_trades(path:Path, expected_symbol:str):
    tr=pd.read_csv(path)
    if not set(TRADES_FIELDS).issubset(tr.columns):raise ValueError("Missing Binance aggTrades fields")
    if tr.empty or not tr.symbol.eq(expected_symbol).all() or not tr.price_kind.eq("last_trade_proxy").all():
        raise ValueError("Binance trade proxy must be from EXACT matching symbol")
    tr["price"]=pd.to_numeric(tr.price,errors="raise")
    tr["agg_id"]=pd.to_numeric(tr.agg_id,errors="raise").astype("int64")
    if not np.isfinite(tr.price).all() or not (tr.price>0).all():raise ValueError("Bad trade price")
    ts=np.array([parse_utc(s) for s in tr.timestamp_utc.astype(str)],dtype=np.int64)
    if (np.diff(ts)<0).any() or (np.diff(tr.agg_id.to_numpy()) != 1).any():
        raise ValueError("Trade times/IDs discontinuous; no silent gaps")
    return tr,ts


def audit_crypto(broker_csv:str|Path,aggtrades_csv:str|Path,out_csv:str|Path,
                 *,symbol:str,max_quote_lag_ms:int=2000,uncertainty_bps:float=1.0):
    if not symbol or symbol in ("EURUSD","GBPUSD","USDJPY") or not symbol.isalnum():
        raise ValueError("Require an identical Binance Spot pair, not a forex pair")
    if max_quote_lag_ms<0 or uncertainty_bps<0:raise ValueError("Bad uncertainty or lag")
    broker_path=Path(broker_csv);trade_path=Path(aggtrades_csv)
    b=_load_broker(broker_path,symbol)
    tr,ts=_load_trades(trade_path,symbol)
    prices=tr.price.to_numpy()
    matches=[]
    for r in b.itertuples(index=False):
        a=int(r.broker_entry_utc.value // 1_000_000);z=int(r.broker_settle_utc.value // 1_000_000)
        i=int(np.searchsorted(ts,a,side="left"));j=int(np.searchsorted(ts,z,side="left"))
        if i>=len(ts) or j>=len(ts) or ts[i]-a>max_quote_lag_ms or ts[j]-z>max_quote_lag_ms:
            matches.append({"contract_id":r.contract_id,"match_status":"UNMATCHED_STALE_OR_MISSING_TRADE"})
            continue
        em,sm=prices[i],prices[j]
        delta_bin=10000*(sm/em-1)
        delta_broker=10000*(r.broker_settle_quote/r.broker_entry_quote-1)
        dr=lambda d: "UP" if d>0 else "DOWN" if d<0 else "TIE"
        ref_dir=dr(delta_bin);broker_dir=dr(delta_broker)
        matches.append({"contract_id":r.contract_id,"match_status":"MATCHED_PROXY_NOT_SETTLEMENT",
                "symbol":symbol,"broker_entry_utc":r.broker_entry_utc.isoformat(),
                "broker_settle_utc":r.broker_settle_utc.isoformat(),
                "reference_entry_utc":pd.Timestamp(ts[i],unit="ms",tz="UTC").isoformat(),
                "reference_settle_utc":pd.Timestamp(ts[j],unit="ms",tz="UTC").isoformat(),
                "entry_ref_lag_ms":int(ts[i]-a),"settle_ref_lag_ms":int(ts[j]-z),
                "broker_entry_quote":r.broker_entry_quote,"broker_settle_quote":r.broker_settle_quote,
                "ref_entry_trade":em,"ref_settle_trade":sm,
                "entry_price_delta_bps":10000*(r.broker_entry_quote/em-1),
                "settle_price_delta_bps":10000*(r.broker_settle_quote/sm-1),
                "broker_direction":broker_dir,"reference_direction":ref_dir,
                "broker_move_bps":delta_broker,"reference_move_bps":delta_bin,
                "direction_mismatch":broker_dir!=ref_dir,
                "uncertain_near_tie":abs(delta_bin)<=uncertainty_bps or abs(delta_broker)<=uncertainty_bps,
                "broker_payout":r.broker_payout})
    out=pd.DataFrame(matches)
    path=Path(out_csv);path.parent.mkdir(parents=True,exist_ok=True);out.to_csv(path,index=False)
    v=out[out.match_status=="MATCHED_PROXY_NOT_SETTLEMENT"]
    result={"market":"BINANCE_SPOT_vs_BROKER_SAME_PAIR","symbol":symbol,
        "broker_contracts":len(b),"matched":len(v),"unmatched":len(out)-len(v),
        "mean_abs_entry_price_delta_bps":float(v.entry_price_delta_bps.abs().mean()) if len(v) else None,
        "mean_abs_settle_price_delta_bps":float(v.settle_price_delta_bps.abs().mean()) if len(v) else None,
        "direction_mismatch_count":int(v.direction_mismatch.sum()) if len(v) else 0,
        "direction_mismatch_rate":float(v.direction_mismatch.mean()) if len(v) else None,
        "near_tie_count":int(v.uncertain_near_tie.sum()) if len(v) else 0,
        "comparison_status":"OBSERVED_BROKER_EXPORT_UNVERIFIED",
        "broker_authenticity_verified":False,"broker_settlement_reproduced":False,
        "broker_csv_sha256":sha256(broker_path),"binance_trade_csv_sha256":sha256(trade_path),
        "warning":"Observed quote mismatch is evidence only for identical pair and quote unit. Binance trades are not broker settlement prices; broker export authenticity and quote method not verified."}
    (path.parent/(path.stem+"_summary.json")).write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding="utf-8")
    return result


def main(argv=None):
    p=argparse.ArgumentParser(description="Offline broker comparison; only identical BTCUSDT-like pairs")
    p.add_argument("--broker",required=True);p.add_argument("--aggtrades",required=True)
    p.add_argument("--symbol",required=True);p.add_argument("--out",default="outputs/binance_broker_audit.csv")
    p.add_argument("--max-lag-ms",type=int,default=2000)
    p.add_argument("--uncertainty-bps",type=float,default=1.0)
    a=p.parse_args(argv)
    print(json.dumps(audit_crypto(a.broker,a.aggtrades,a.out,symbol=a.symbol,
                         max_quote_lag_ms=a.max_lag_ms,uncertainty_bps=a.uncertainty_bps),indent=2,ensure_ascii=False))

if __name__=="__main__":main()
