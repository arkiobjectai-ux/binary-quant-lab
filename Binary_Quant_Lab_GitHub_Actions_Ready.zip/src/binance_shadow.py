"""Unverified simulated 300s last-trade proxy outcomes for Binance crypto only.

Never reuse price-only aggTrades as bid/ask and never call these outcomes
Pocket Option settlement, executed trades, or real profits.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
from .binance_public import parse_utc
from .binance_audit import _load_trades


def simulate_300s(signals_csv, aggtrades_csv, symbol, out_csv, *, entry_delay_ms=1000,
                  max_lag_ms=2000,payout=.80,uncertainty_bps=1.0):
    if entry_delay_ms < 0 or max_lag_ms<0 or not 0<payout<=2 or uncertainty_bps<0:
        raise ValueError("Invalid simulation assumptions")
    signals=pd.read_csv(signals_csv)
    if not {"decision_utc","available_at_utc","model_name","signal","source_symbol","expiry_seconds"}.issubset(signals.columns):
        raise ValueError("Bad signal schema")
    if not signals.source_symbol.eq(symbol).all() or not signals.expiry_seconds.eq(300).all():
        raise ValueError("Symbol or expiry mismatch")
    if not signals.signal.isin(("CALL","PUT","WAIT")).all():raise ValueError("Unknown signal")
    trades,ts=_load_trades(Path(aggtrades_csv),symbol);prices=trades.price.to_numpy()
    signals=signals.assign(dec_ms=signals.decision_utc.map(parse_utc),
                           avail_ms=signals.available_at_utc.map(parse_utc))
    if (signals.avail_ms<signals.dec_ms).any():raise ValueError("Forecast available before its input closed")
    if signals.duplicated(["model_name","decision_utc"]).any():raise ValueError("Duplicate model decision")
    signals=signals.sort_values(["model_name","dec_ms"])
    rows=[];blocked_until={}
    for s in signals.itertuples(index=False):
        if s.signal=="WAIT":
            rows.append({"decision_utc":s.decision_utc,"model_name":s.model_name,"signal":"WAIT","status":"WAIT"})
            continue
        if int(s.avail_ms) <= blocked_until.get(s.model_name,-1):
            rows.append({"decision_utc":s.decision_utc,"model_name":s.model_name,"signal":s.signal,"status":"OVERLAP_SKIPPED"})
            continue
        target=int(s.avail_ms)+entry_delay_ms
        i=int(np.searchsorted(ts,target,side="left"))
        if i==len(ts) or ts[i]-target>max_lag_ms:
            rows.append({"decision_utc":s.decision_utc,"model_name":s.model_name,"signal":s.signal,"status":"NO_FRESH_ENTRY_TRADE"})
            continue
        expiry=int(ts[i])+300_000
        j=int(np.searchsorted(ts,expiry,side="left"))
        if j==len(ts) or ts[j]-expiry>max_lag_ms:
            rows.append({"decision_utc":s.decision_utc,"model_name":s.model_name,"signal":s.signal,"status":"NO_FRESH_EXPIRY_TRADE"})
            continue
        entry=prices[i];settle=prices[j];move=10_000*(settle/entry-1)
        ambiguous=abs(move)<=uncertainty_bps
        won=((s.signal=="CALL" and move>0) or (s.signal=="PUT" and move<0))
        rows.append({"decision_utc":s.decision_utc,"model_name":s.model_name,"signal":s.signal,
            "status":"PROXY_UNCERTAIN" if ambiguous else "PROXY_ONLY",
            "entry_utc":pd.Timestamp(ts[i],unit="ms",tz="UTC").isoformat(),
            "expiry_utc":pd.Timestamp(ts[j],unit="ms",tz="UTC").isoformat(),
            "entry_trade":entry,"expiry_trade":settle,"reference_move_bps":move,
            "proxy_result":"UNCERTAIN" if ambiguous else "WIN" if won else "LOSS",
            "net_return_per_unit":float('nan') if ambiguous else payout if won else -1.0})
        blocked_until[s.model_name]=int(ts[j])
    report=pd.DataFrame(rows)
    out=Path(out_csv);out.parent.mkdir(parents=True,exist_ok=True);report.to_csv(out,index=False)
    usable=report[report.status=="PROXY_ONLY"]
    summary={"market":"BINANCE_SPOT_TRADE_PROXY", "symbol":symbol,"signal_rows":len(report),
        "usable_proxy_outcomes":len(usable),"uncertain_proxy_outcomes":int((report.status=="PROXY_UNCERTAIN").sum()),
        "mean_proxy_return":float(usable.net_return_per_unit.mean()) if len(usable) else None,
        "proxy_win_rate":float((usable.proxy_result=="WIN").mean()) if len(usable) else None,
        "payout_assumption":payout,"expiry_seconds":300,"broker_outcomes_verified":False,
        "kronos_base_executed":False,
        "warning":"Historical Binance trade-proxy simulation only; no bid/ask, quote-source concordance, live fill or broker settlement."}
    (out.parent/(out.stem+"_summary.json")).write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
    return summary


def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument("--signals",required=True);p.add_argument("--aggtrades",required=True)
    p.add_argument("--symbol",required=True);p.add_argument("--out",default="outputs/binance_shadow.csv")
    p.add_argument("--delay-ms",type=int,default=1000)
    p.add_argument("--max-lag-ms",type=int,default=2000)
    p.add_argument("--payout",type=float,default=.8)
    p.add_argument("--uncertainty-bps",type=float,default=1.0)
    a=p.parse_args(argv)
    r=simulate_300s(a.signals,a.aggtrades,a.symbol,a.out,entry_delay_ms=a.delay_ms,
                    max_lag_ms=a.max_lag_ms,payout=a.payout,uncertainty_bps=a.uncertainty_bps)
    print(json.dumps(r,ensure_ascii=False,indent=2))

if __name__=="__main__":main()
