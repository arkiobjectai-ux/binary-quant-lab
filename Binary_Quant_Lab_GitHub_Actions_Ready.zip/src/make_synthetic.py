"""Deterministic artificial FX ticks for smoke tests. NEVER MARKET EVIDENCE."""
from __future__ import annotations
import argparse,datetime as dt,hashlib,json
from pathlib import Path
import numpy as np
import pandas as pd

def make(out,daily_hours=7,interval_seconds=5,seed=20261110):
    if interval_seconds<1 or 60%interval_seconds:raise ValueError('interval divides minute')
    rng=np.random.default_rng(seed)
    chunks=[]; price=1.08000
    for offset in range(5):
        day=dt.date(2025,2,10)+dt.timedelta(days=offset)
        begin=pd.Timestamp(day).tz_localize('UTC')+pd.Timedelta(hours=9)
        times=pd.date_range(begin,periods=daily_hours*3600//interval_seconds,freq=f'{interval_seconds}s')
        n=len(times)
        # AR(1) tiny synthetic drift; DEMONSTRATION ONLY.
        innovation=rng.normal(0,.12,n)
        ar=0.0;mid=[]
        for delta in innovation:
            ar=.09*ar+delta
            price+=ar*0.0001
            mid.append(price)
        mid=np.array(mid)
        spread=rng.uniform(.7,1.4,n)*0.0001
        chunks.append(pd.DataFrame({'timestamp_utc':times.strftime('%Y-%m-%dT%H:%M:%S.%fZ'),
                      'bid':mid-spread/2,'ask':mid+spread/2}))
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    ticks=pd.concat(chunks,ignore_index=True)
    ticks.to_csv(out,index=False,float_format='%.7f')
    h=hashlib.sha256(out.read_bytes()).hexdigest()
    manifest={'dataset_kind':'synthetic','instrument':'EURUSD','source':'Generated artificial random-walk FX ticks by make_synthetic.py',
              'retrieved_utc':'2026-11-10T00:00:00Z','use_rights_note':'Generated locally, research/testing only; not indicative of any market',
              'timezone':'UTC','pricing':'bid_ask','source_file_sha256':h,
              'seed':seed,'data_not_genuine_market':True}
    Path(str(out)+'.manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
    return {'tick_count':len(ticks),'file':str(out),'sha256':h}

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',default='examples/synthetic_eurusd_ticks.csv')
    a=ap.parse_args();print(json.dumps(make(a.out),indent=2))
