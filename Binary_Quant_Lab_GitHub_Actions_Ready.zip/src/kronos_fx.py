"""Point-in-time Kronos FX adapter. No weights are included. Offline-only reference forecasts.

Kronos-base (102.3M) is loaded exclusively from an installed official Kronos repo
and official NeoQuasar checkpoints, with no automatic substitution of smaller models.
Historical availability is a *replay assumption* using measured present-day inference latency.
"""
from __future__ import annotations
import argparse, datetime as dt, hashlib, importlib, json, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
from .benchmark import distinct_days_frame

MODELS={'base':'NeoQuasar/Kronos-base','small':'NeoQuasar/Kronos-small'}
TOKENIZER='NeoQuasar/Kronos-Tokenizer-base'

def bars_from_csv(path):
    b=pd.read_csv(path)
    needed={'timestamp_utc','open','high','low','close','count','close_at_utc','last_tick_time'}
    if not needed.issubset(b.columns):raise ValueError('Missing bar fields: '+str(needed-set(b.columns)))
    for c in ('timestamp_utc','close_at_utc','last_tick_time'):
        b[c]=pd.to_datetime(b[c],utc=True,errors='coerce')
    if b.timestamp_utc.isna().any() or b.timestamp_utc.duplicated().any():raise ValueError('Invalid UTC bars')
    b=b.set_index('timestamp_utc').sort_index()
    if not b.index.is_monotonic_increasing:raise ValueError('Not increasing')
    if not ((b.close_at_utc-b.index)==pd.Timedelta(minutes=1)).all():raise ValueError('Bar close timestamp mismatch')
    if not b.index.is_unique:raise ValueError('Duplicated minute bars')
    return b

def sample_asof(bars,at_index,context=256,pred_len=5):
    """Use only complete [t-255,t] bars at or before decision close. Never access future prices."""
    if not 21<=context<=512:raise ValueError('Context must be between 21 and Kronos 512 maximum')
    if pred_len!=5:raise ValueError('This is a five-minute horizon only')
    if at_index<context-1 or at_index>=len(bars):return None
    past=bars.iloc[at_index-context+1:at_index+1]
    if not (past['count']>0).all():return None
    if len(past)!=context or not (np.diff(past.index.asi8)==60*10**9).all():return None
    if past[['open','high','low','close']].isna().any().any():return None
    if (past[['open','high','low','close']]<=0).any().any():return None
    if (past['high']+1e-10<past[['open','close','low']].max(axis=1)).any():return None
    if (past['low']-1e-10>past[['open','close','high']].min(axis=1)).any():return None
    freshness=(past.close_at_utc.iloc[-1]-past.last_tick_time.iloc[-1]).total_seconds()
    if not 0<=freshness<=12:return None
    past_open=past.index[-1]
    decision=past_open+pd.Timedelta(minutes=1)
    x=past[['open','high','low','close']].copy().reset_index(drop=True)
    x_ts=pd.Series(past.index.tz_convert(None))  # UTC, timezone removed for model calendar feature extraction
    y_ts=pd.Series(pd.date_range(start=decision,periods=5,freq='1min',tz='UTC').tz_convert(None))
    return {'historical':x,'x_timestamp':x_ts,'y_timestamp':y_ts,
            'decision_utc':decision,'last_known_close':float(past.close.iloc[-1]),
            'source_end_utc':decision,'future_clock_only':True}

def eligible_samples(bars,context=256,stride=5,max_samples=20,holdout_from=None):
    if stride<1 or max_samples<1:raise ValueError('Invalid stride/max_samples')
    # Holdout chosen from observation dates, not future labels.
    if holdout_from is None:
        valid=bars.loc[bars['count']>0].copy()
        valid['decision_utc']=valid.close_at_utc
        _,start,_=distinct_days_frame(valid[['decision_utc']])
    else:start=pd.Timestamp(holdout_from)
    points=[]
    for i in range(context-1,len(bars),stride):
        if bars.index[i]+pd.Timedelta(minutes=1)<start:continue
        sample=sample_asof(bars,i,context=context,pred_len=5)
        if sample is not None:
            points.append(sample)
            if len(points)>=max_samples:break
    return points,start

def _load_predictor(repo_path,checkpoint,device,max_context):
    if checkpoint not in MODELS:raise ValueError('Only explicit base/small allowed')
    repo=Path(repo_path).expanduser().resolve()
    if not (repo/'model').is_dir():
        raise FileNotFoundError('Official Kronos repo not installed at '+str(repo))
    sys.path.insert(0,str(repo))
    try:
        mod=importlib.import_module('model')
        tokenizer=mod.KronosTokenizer.from_pretrained(TOKENIZER)
        model=mod.Kronos.from_pretrained(MODELS[checkpoint])
        return mod.KronosPredictor(model,tokenizer,device=device,max_context=max_context)
    finally:sys.path.remove(str(repo))

def replay_forecast(bars,predictor,*,checkpoint='base',context=256,stride=5,
                    max_samples=20,threshold_pips=1.5,pipeline_delay_ms=1000,
                    max_signal_age_seconds=30,holdout_from=None):
    if threshold_pips<0 or pipeline_delay_ms<0 or max_signal_age_seconds<=0:raise ValueError('bad parameter')
    samples,start=eligible_samples(bars,context=context,stride=stride,max_samples=max_samples,holdout_from=holdout_from)
    rows=[]
    for s in samples:
        start_time=time.perf_counter()
        pred=predictor.predict(df=s['historical'],x_timestamp=s['x_timestamp'],y_timestamp=s['y_timestamp'],
                               pred_len=5,T=1.0,top_p=0.9,sample_count=1,verbose=False)
        runtime=time.perf_counter()-start_time
        if len(pred)!=5 or 'close' not in pred.columns or not np.isfinite(pred.close.iloc[-1]):
            raise ValueError('Kronos returned invalid prediction')
        future_close=float(pred.close.iloc[-1])
        change=(future_close-s['last_known_close'])/0.0001
        hypothetical_latency=runtime+pipeline_delay_ms/1000
        stale=hypothetical_latency>max_signal_age_seconds
        signal='WAIT' if stale else ('CALL' if change>threshold_pips else 'PUT' if change< -threshold_pips else 'WAIT')
        available=s['decision_utc']+pd.Timedelta(seconds=hypothetical_latency)
        rows.append({'decision_utc':s['decision_utc'].isoformat().replace('+00:00','Z'),
                     'available_at_utc':available.isoformat().replace('+00:00','Z'),
                     'model_name':'Kronos-'+checkpoint,
                     'signal':signal,'predicted_change_pips':change,
                     'forecast_close':future_close,'last_known_close':s['last_known_close'],
                     'actual_inference_seconds_measured_now':runtime,
                     'replay_assumed_pipeline_delay_ms':pipeline_delay_ms,
                     'availability_mode':'HISTORICAL_REPLAY_NOT_REALTIME',
                     'timing_status':'STALE_FAIL_CLOSED' if stale else 'REPLAY_ASSUMED'})
    return pd.DataFrame(rows),{'checkpoint':MODELS[checkpoint],'tokenizer':TOKENIZER,
                 'selected_holdout_first_utc':start.isoformat(),'sample_count':len(rows),
                 'signals_usable_for_reference_evaluation':sum(r['timing_status']=='REPLAY_ASSUMED' for r in rows),
                 'no_order_submission':True,'broker_settlement_verified':False,
                 'prediction_outcomes_not_in_inputs':True,
                 'runtime_is_measured_now_not_at_historical_decision':True,
                 'important':'Predicted close is five future M1 bars ahead, NOT the precise broker expiry price.'}

def main():
    p=argparse.ArgumentParser(description='Kronos-base EURUSD as-of runner; reference research only')
    p.add_argument('--bars',required=True);p.add_argument('--repo-path',default='Kronos')
    p.add_argument('--checkpoint',choices=list(MODELS),default='base')
    p.add_argument('--device',default='cpu');p.add_argument('--out',default='outputs/kronos_replay')
    p.add_argument('--max-samples',type=int,default=20);p.add_argument('--stride',type=int,default=5)
    p.add_argument('--context',type=int,default=256);p.add_argument('--threshold-pips',type=float,default=1.5)
    p.add_argument('--pipeline-delay-ms',type=int,default=1000)
    p.add_argument('--check-only',action='store_true')
    p.add_argument('--reference-report',help='Benchmark report.json: use its unchanged holdout start for fair comparisons')
    a=p.parse_args()
    bars=bars_from_csv(a.bars)
    split_from=None
    if a.reference_report:
        report=json.loads(Path(a.reference_report).read_text(encoding='utf8'))
        split_from=report['split']['holdout_first_utc']
    samples,start=eligible_samples(bars,context=a.context,stride=a.stride,max_samples=a.max_samples,holdout_from=split_from)
    out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    ready={'requested_checkpoint':MODELS[a.checkpoint],'repo_exists':(Path(a.repo_path)/'model').is_dir(),
           'data_asof_samples':len(samples),'holdout_first_utc':str(start),
           'weights_loaded':False,'inference_executed':False,'broker_settlement_verified':False,
           'execution_mode':'CHECK_ONLY' if a.check_only else 'INFERENCE_REQUESTED'}
    if a.check_only:
        (out/'readiness.json').write_text(json.dumps(ready,indent=2,ensure_ascii=False),encoding='utf8')
        print(json.dumps(ready,indent=2,ensure_ascii=False));return
    predictor=_load_predictor(a.repo_path,a.checkpoint,a.device,a.context)
    res,report=replay_forecast(bars,predictor,checkpoint=a.checkpoint,context=a.context,
                stride=a.stride,max_samples=a.max_samples,threshold_pips=a.threshold_pips,
                pipeline_delay_ms=a.pipeline_delay_ms,holdout_from=split_from)
    if res.empty:raise ValueError('No valid as-of samples. Nothing written.')
    res.to_csv(out/'kronos_forecasts_replay.csv',index=False)
    valid=res.loc[res.timing_status=='REPLAY_ASSUMED', ['decision_utc','available_at_utc','model_name','signal']]
    if not valid.empty:
        valid.to_csv(out/'external_forecasts_for_reference.csv',index=False)
    report.update({'weights_loaded':True,'inference_executed':True,'checkpoint_substitution':False})
    (out/'inference_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf8')
    print(json.dumps(report,indent=2,ensure_ascii=False))
if __name__=='__main__':main()
