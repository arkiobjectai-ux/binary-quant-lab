"""Three pre-declared, non-optimized example strategies for 300s binary research.

Features available only after each completed M1 bar. No broker orders.
Strategies are illustrative baselines, NOT Kronos-base predictions.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from .binance_public import parse_utc,utc_iso_ms

MODEL_NAMES={
    'momentum':'mom5_z1p2',
    'reversion':'meanrev20_z1p6',
    'breakout':'breakout20_prevhi_lo'
}


def validate_bars(bars:pd.DataFrame)->pd.DataFrame:
    required={'open_time_utc','close_at_utc','open','high','low','close','volume','symbol'}
    if not required.issubset(bars.columns):raise ValueError('Missing Binance M1 columns')
    if bars.empty:raise ValueError('Empty bars')
    if len(bars)<40:raise ValueError('Need at least 40 complete M1 bars for strategy indicators')
    if bars.symbol.nunique()!=1:raise ValueError('Mixed symbols not allowed')
    if bars.symbol.iloc[0] in ('EURUSD','USDJPY','GBPUSD'):
        raise ValueError('Binance Spot backtest only; not EURUSD FX')
    a=np.array([parse_utc(x) for x in bars.open_time_utc.astype(str)],dtype='int64')
    b=np.array([parse_utc(x) for x in bars.close_at_utc.astype(str)],dtype='int64')
    if (np.diff(a)!=60_000).any() or (b!=a+60_000).any():
        raise ValueError('Non-consecutive or non-closed M1 bars')
    for column in ('open','high','low','close','volume'):
        v=pd.to_numeric(bars[column],errors='raise').to_numpy(dtype='float64')
        if not np.isfinite(v).all():raise ValueError('Bad OHLCV')
        if (v<0).any() or (column!='volume' and (v<=0).any()):raise ValueError('Bad OHLCV')
    if ((bars.low.astype(float)>bars.high.astype(float)) |
        (bars.low.astype(float)>bars[['open','close']].astype(float).min(axis=1)) |
        (bars.high.astype(float)<bars[['open','close']].astype(float).max(axis=1))).any():
        raise ValueError('Invalid highs/lows')
    return bars.copy()


def generate_baselines(bars:pd.DataFrame,*,latency_ms:int=1000)->pd.DataFrame:
    if not 0<=latency_ms<=60_000:raise ValueError('Bad assumed inference latency')
    bars=validate_bars(bars)
    c=bars.close.astype(float)
    logret=np.log(c).diff()
    mom=np.log(c/c.shift(5))
    vol=logret.rolling(20,min_periods=20).std()*np.sqrt(5)
    mz=(mom/vol.replace(0,np.nan)).replace([np.inf,-np.inf],np.nan)
    ma=c.rolling(20,min_periods=20).mean()
    dev=c.rolling(20,min_periods=20).std()
    rz=((c-ma)/dev.replace(0,np.nan)).replace([np.inf,-np.inf],np.nan)
    prev_high=bars.high.astype(float).shift(1).rolling(20,min_periods=20).max()
    prev_low=bars.low.astype(float).shift(1).rolling(20,min_periods=20).min()
    rows=[]
    for i in range(21,len(bars)):
        when=parse_utc(str(bars.close_at_utc.iloc[i]))
        base={'decision_utc':utc_iso_ms(when),'available_at_utc':utc_iso_ms(when+latency_ms),
              'source_symbol':str(bars.symbol.iloc[i]),'expiry_seconds':300,
              'source_end_utc':utc_iso_ms(when),'model_category':'predeclared_untrained_baseline'}
        m=float(mz.iloc[i]);r=float(rz.iloc[i])
        sets={
            MODEL_NAMES['momentum']:('CALL' if m>=1.2 else 'PUT' if m<=-1.2 else 'WAIT') if np.isfinite(m) else 'WAIT',
            MODEL_NAMES['reversion']:('PUT' if r>=1.6 else 'CALL' if r<=-1.6 else 'WAIT') if np.isfinite(r) else 'WAIT',
            MODEL_NAMES['breakout']:('CALL' if c.iloc[i]>prev_high.iloc[i] else 'PUT' if c.iloc[i]<prev_low.iloc[i] else 'WAIT'),
        }
        for name,signal in sets.items():rows.append({'model_name':name,'signal':signal,**base})
    return pd.DataFrame(rows)


def split_report(outcomes:pd.DataFrame,payout:float=.8)->dict:
    """Fixed chronological 60/20/20 split, with no tuning/selection on holdout."""
    if not (0<payout<=2):raise ValueError('Invalid payout')
    if not {'decision_utc','model_name','signal','status','proxy_result','net_return_per_unit'}.issubset(outcomes.columns):
        raise ValueError('Required backtest result fields absent')
    times=sorted(outcomes.decision_utc.unique())
    if len(times)<5:raise ValueError('Too few distinct decision timestamps for split')
    first=times[int(.6*len(times))];second=times[int(.8*len(times))]
    out=outcomes.copy()
    out['split']=np.where(out.decision_utc<first,'development',np.where(out.decision_utc<second,'validation','holdout'))
    stats=[]
    for (name,split),d in out.groupby(['model_name','split']):
        v=d[d.status=='PROXY_ONLY'];wins=int((v.proxy_result=='WIN').sum());n=len(v)
        stats.append({'model_name':name,'split':split,'decisions':len(d),
                      'valid_trade_proxy_trials':n,'wins':wins,
                      'win_rate':wins/n if n else None,
                      'avg_proxy_return':float(v.net_return_per_unit.mean()) if n else None,
                      'uncertain':int((d.status=='PROXY_UNCERTAIN').sum()),
                      'overlap_skipped':int((d.status=='OVERLAP_SKIPPED').sum()),
                      'no_fresh_price':int(d.status.str.startswith('NO_FRESH_').sum()),
                      'wait':int((d.signal=='WAIT').sum())})
    return {'split_cutoffs_utc':{'validation_start':first,'holdout_start':second},
            'assumed_payout':payout,'breakeven_win_rate':1/(1+payout),
            'source':'BINANCE_SPOT_AGGTRADE_PROXY','broker_settlement_verified':False,
            'kronos_base_executed':False,'strategy_training_performed':False,
            'strategy_parameters_optimized':False,'performance_rows':stats,
            'limitations':['Results are last-trade price proxies, not broker settlements',
                           'Proxy quote lag, uncertainty band and payout assumptions change outcomes',
                           'Chronological holdout without tuning is not sufficient evidence of stable profitability']}


def main(argv=None):
    p=argparse.ArgumentParser(description='Binance Spot 300s strategy research (no live orders)')
    p.add_argument('--bars',required=True)
    p.add_argument('--aggtrades',default=None,help='Same-symbol aggTrades CSV for 300-second shadow simulation')
    p.add_argument('--out',default='outputs/binance_strategy_research')
    p.add_argument('--latency-ms',type=int,default=1000)
    p.add_argument('--entry-delay-ms',type=int,default=1000)
    p.add_argument('--max-lag-ms',type=int,default=2000)
    p.add_argument('--payout',type=float,default=.8)
    p.add_argument('--uncertainty-bps',type=float,default=1.0)
    a=p.parse_args(argv)
    out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    bars=validate_bars(pd.read_csv(a.bars));sym=str(bars.symbol.iloc[0])
    signals=generate_baselines(bars,latency_ms=a.latency_ms)
    sig_file=out/'signals_3_strategies.csv';signals.to_csv(sig_file,index=False)
    report={'status':'signals_only_not_backtested','market':'BINANCE_SPOT','symbol':sym,
            'bars':len(bars),'signals_total':len(signals),'strategies':list(MODEL_NAMES.values()),
            'broker_settlement_verified':False,'kronos_base_executed':False,
            'signals_csv':str(sig_file)}
    if a.aggtrades:
        # Import price-based trials from existing strict proxy backtester.
        from .binance_shadow import simulate_300s
        summary=simulate_300s(sig_file,a.aggtrades,sym,out/'proxy_trades.csv',
                        entry_delay_ms=a.entry_delay_ms,max_lag_ms=a.max_lag_ms,
                        payout=a.payout,uncertainty_bps=a.uncertainty_bps)
        trials=pd.read_csv(out/'proxy_trades.csv')
        # Empty proxy outcomes still give transparent coverage report, not a fabricated profit.
        if (len(trials.decision_utc.unique())>=5 and
            {'proxy_result','net_return_per_unit'}.issubset(trials.columns) and
            summary['usable_proxy_outcomes'] > 0):
            split=split_report(trials,payout=a.payout)
            report={**report,**split,'status':'completed_proxy_only','proxy_summary':summary}
        else:
            report={**report,'status':'insufficient_coverage','proxy_summary':summary}
    (out/'research_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
