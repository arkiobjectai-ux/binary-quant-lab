"""Self-contained offline static report; NO market performance claims."""
from __future__ import annotations
import argparse,html,json
from pathlib import Path
import pandas as pd


def render(path,out):
    report=json.loads(Path(path).read_text(encoding='utf-8'))
    data=report['metrics_reference_only']
    label={'no_trade':'WAIT کامل','always_call':'همیشه CALL','momentum5':'مومنتوم ۵ دقیقه','contrarian5':'بازگشت به میانگین','logistic':'رگرسیون لجستیک'}
    def show(x,suffix=''):
        return '—' if x is None else f'{x}{suffix}'
    body=''.join(f'<tr><td>{html.escape(label.get(k,k))}</td><td>{v["trades"]}</td><td>{show(v["winrate_percent"],"٪")}</td>'
         f'<td>{show(v["roi_per_stake_percent"],"٪")}</td><td>{show(v["worst_case_roi_percent"],"٪")}</td>'
         f'<td>{show(v["best_case_roi_percent"],"٪")}</td></tr>' for k,v in data.items())
    p=report['policy'];split=report['split']
    note='داده‌های کاملاً ساختگی؛ فقط تست سلامت کد' if report['provenance']['dataset_kind']=='synthetic' else 'فایل ورودی خوداظهاریِ واقعی؛ منشأ مستقل هنوز تأیید نشده است'
    markup=f'''<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Binary Quant Lab · v0.4</title><style>
    body{{font:16px/1.9 Tahoma,Arial,sans-serif;max-width:1100px;margin:auto;padding:32px;background:#f8f9fc;color:#172238}}
    h1{{font-size:30px}} h2{{margin-top:38px}} .alert{{background:#fff1d5;border:2px solid #c58826;border-radius:12px;padding:20px;font-weight:bold}}
    .meta{{display:grid;grid-template-columns:repeat(auto-fit,minmax(165px,1fr));gap:12px;margin:20px 0}}
    .tile{{background:white;border:1px solid #e2e5ef;border-radius:12px;padding:18px}}.tile b{{display:block;font-size:21px}}
    table{{border-collapse:collapse;width:100%;background:white;font-size:14px;overflow-x:auto}}td,th{{padding:11px;border:1px solid #e4e7ee;text-align:right}}th{{background:#e8eefb}}
    .small{{color:#55657f;font-size:14px}} .foot{{margin-top:35px;padding-top:12px;border-top:1px solid #ddd}}
    </style></head><body>
    <p class="small">Binary Quant Lab / گزارش آزمایشی آفلاین / v0.4</p>
    <h1>ممیزی تسویه باینری ۳۰۰ ثانیه‌ای روی EUR/USD</h1>
    <div class="alert">⚠️ {html.escape(note)}<br>این گزارش اثبات سودآوری نیست، داده بروکر را ندارد، Kronos-base را اجرا نکرده و مجوز استفاده واقعی از باینری نیست.</div>
    <div class="meta"><div class="tile">تعداد تیک‌ها<b>{report['tick_rows']:,}</b></div><div class="tile">جفت ورود/تسویه مرجع<b>{report['reference_pairs']:,}</b></div>
    <div class="tile">نرخ پرداخت فرضی<b>{int(p['payout']*100)}٪</b></div><div class="tile">درصد برد سربه‌سر<b>{report['assumed_payout_break_even_winrate_percent']}٪</b></div>
    <div class="tile">تأخیر فرضی ورود<b>{p['decision_latency_seconds']} ثانیه</b></div><div class="tile">پنجره پیش‌بینی<b>۳۰۰ ثانیه</b></div></div>
    <h2>نتایج روی قسمت جداشده آخر داده</h2>
    <p class="small">سه قسمت زمانی داریم: آموزش {split['train_days']} روز، اعتبارسنجی {split['validation_days']} روز و آزمون نهایی {split['holdout_days']} روز. در این دمو اعتبارسنجی برای تنظیم استفاده نشده. هر مدل در هر زمان فقط یک موقعیت فرضی باز دارد. محاسبه بر حسب واحد پول فرضی و بدون ارسال سفارش است.</p>
    <table><tr><th>مدل</th><th>تعداد معاملات فرضی</th><th>برد</th><th>بازده متوسط بر هر واحد شرط</th><th>سناریوی محافظه‌کارانه اختلاف قیمت</th><th>سناریوی خوش‌بینانه اختلاف قیمت</th></tr>{body}</table>
    <h2>خروجی‌های قابل بازبینی</h2><p>report.json، reference_trade_trials.csv، holdout_signals.csv، assumption_sensitivity.csv و derived_m1_bars.csv</p>
    <h2>آنچه هنوز مجهول است</h2><p>کیفیت داده واقعی در بازه‌های طولانی، دقت Kronos-base، نرخ برد روی داده بازار، اختلاف زمان و قیمت با بروکر منتخب، پرداخت در لحظه سفارش و اعتبار قانونی عرضه محصول.</p>
    <div class="foot small">این گزارش صرفاً شبیه‌سازی پژوهشی است. هیچ سود یا بازده آینده‌ای را تضمین نمی‌کند.</div>
    </body></html>'''
    p=Path(out);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(markup,encoding='utf-8')

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--report',required=True);a.add_argument('--out',required=True)
    b=a.parse_args();render(b.report,b.out)
