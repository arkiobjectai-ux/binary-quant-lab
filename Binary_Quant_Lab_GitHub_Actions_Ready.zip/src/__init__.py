"""300-second binary settlement research, not a broker connector."""
