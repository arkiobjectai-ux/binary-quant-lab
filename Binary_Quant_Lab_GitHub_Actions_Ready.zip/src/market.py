"""Strict, point-in-time FX tick ingestion and complete M1 bars, UTC only."""
from __future__ import annotations
import hashlib, json
from pathlib import Path
import numpy as np
import pandas as pd

SCHEMA = ('timestamp_utc', 'bid', 'ask')


def digest(path):
    s=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda: f.read(1<<20),b''): s.update(b)
    return s.hexdigest()


def validate_manifest(manifest_path: str|Path, ticks_path: str|Path):
    d=json.loads(Path(manifest_path).read_text(encoding='utf-8'))
    fields=('dataset_kind','instrument','source','retrieved_utc','use_rights_note','timezone','pricing','source_file_sha256')
    missing=[k for k in fields if not d.get(k)]
    if missing: raise ValueError('Manifest missing '+','.join(missing))
    if d['dataset_kind'] not in ('synthetic','real'): raise ValueError('Bad data kind')
    if d['timezone']!='UTC' or d['instrument']!='EURUSD' or d['pricing']!='bid_ask':
        raise ValueError('Require EURUSD, bid_ask, UTC')
    date=pd.Timestamp(d['retrieved_utc'])
    if date.tzinfo is None or date.utcoffset().total_seconds()!=0: raise ValueError('retrieved_utc must be UTC')
    if d['use_rights_note'].lower() in ('unknown','none','unverified'):
        raise ValueError('Must explicitly declare use rights notes')
    if digest(ticks_path).lower()!=str(d['source_file_sha256']).lower():
        raise ValueError('SHA256 mismatch: tick CSV changed since provenance record')
    d['independently_audited'] = False
    d['is_real_data'] = d['dataset_kind']=='real'
    return d


def load_ticks(csv_path, manifest_path=None):
    path=Path(csv_path)
    manifest=validate_manifest(manifest_path,path) if manifest_path else {'dataset_kind':'unverified','independently_audited':False}
    df=pd.read_csv(path, usecols=list(SCHEMA))
    if len(df)<2: raise ValueError('Need at least two ticks')
    if df[list(SCHEMA)].isna().any().any():raise ValueError('Null tick field')
    # Must preserve explicit UTC; naive datetimes are not accepted.
    raw=df['timestamp_utc'].astype(str)
    if not raw.str.endswith(('Z','+00:00')).all(): raise ValueError('Tick timestamps must specify UTC')
    df['timestamp_utc']=pd.to_datetime(df['timestamp_utc'],utc=True,errors='raise')
    for key in ('bid','ask'):df[key]=pd.to_numeric(df[key],errors='raise')
    p=df[['bid','ask']].to_numpy(dtype='float64')
    if not np.isfinite(p).all() or (p<=0).any() or (df.bid>=df.ask).any():
        raise ValueError('Invalid, negative or crossed quotes')
    t=df.timestamp_utc.astype('int64').to_numpy()
    if not (np.diff(t)>0).all(): raise ValueError('Ticks must have strictly increasing unique timestamps')
    df['mid']=(df['bid']+df['ask'])/2
    df['spread_pips']=(df['ask']-df['bid'])/0.0001
    return df,manifest


def complete_m1_bars(ticks: pd.DataFrame):
    """Bar at 12:00 holds ticks [12:00,12:01); only known at 12:01."""
    x=ticks.set_index('timestamp_utc')
    m=x['mid'].resample('1min',closed='left',label='left').ohlc()
    m['count']=x['mid'].resample('1min').count()
    m['last_bid']=x['bid'].resample('1min').last()
    m['last_ask']=x['ask'].resample('1min').last()
    m['spread_pips']=x['spread_pips'].resample('1min').last()
    m['close_at_utc']=m.index+pd.Timedelta(minutes=1)
    m['last_tick_time']=x['mid'].resample('1min').apply(lambda y:y.index[-1] if len(y) else pd.NaT)
    return m


def build_decisions(bars: pd.DataFrame, *, min_history=21, max_bar_lag_seconds=12):
    """No forward-filled bars: missing minute invalidates the rolling window."""
    if min_history<21: raise ValueError('Need at least 21 complete minutes')
    c=bars['close']
    n=bars['count']
    complete=(n>0).rolling(min_history,min_periods=min_history).sum()==min_history
    z=pd.DataFrame(index=bars.index)
    z['decision_utc']=bars['close_at_utc']
    z['lag_seconds']=(bars['close_at_utc']-bars['last_tick_time']).dt.total_seconds()
    z['momentum_1_pips']=(c-c.shift(1))/0.0001
    z['momentum_5_pips']=(c-c.shift(5))/0.0001
    z['momentum_15_pips']=(c-c.shift(15))/0.0001
    z['volatility20_pips']=(c.diff()/0.0001).rolling(20).std()
    z['spread_pips']=bars['spread_pips']
    z['hour_utc']=z.decision_utc.dt.hour
    z['minute_utc']=z.decision_utc.dt.minute
    z['last_mid']=c
    keep=complete & z.lag_seconds.ge(0) & z.lag_seconds.le(max_bar_lag_seconds)
    return z.loc[keep].dropna().reset_index(drop=True)
