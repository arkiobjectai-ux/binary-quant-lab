"""300-second reference-tick binary settlement, explicitly NOT broker settlement."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd

@dataclass(frozen=True)
class Policy:
    expiry_seconds:int=300
    decision_latency_seconds:float=1.0
    max_entry_lag_seconds:float=5.0
    max_exit_lag_seconds:float=5.0
    max_signal_age_seconds:float=30.0
    uncertainty_pips:float=0.2
    max_entry_spread_pips:float=3.0
    payout:float=0.80
    tie_policy:str='loss'
    def __post_init__(self):
        if self.expiry_seconds!=300: raise ValueError('This engine is exclusively 300 seconds')
        if min(self.decision_latency_seconds,self.max_entry_lag_seconds,self.max_exit_lag_seconds,self.max_signal_age_seconds,self.uncertainty_pips,self.max_entry_spread_pips)<0:raise ValueError('Negative parameter')
        if not 0 < self.payout <= 2:raise ValueError('Payout expressed as decimal fraction, e.g. .80')
        if self.tie_policy not in ('loss','refund'):raise ValueError('Unknown tie handling')


def _pick(ts,ns,target,maxlag):
    idx=int(np.searchsorted(ns, pd.Timestamp(target).value, side='left'))
    if idx >= len(ns): return None
    lag=(ns[idx]-pd.Timestamp(target).value)/1e9
    return idx if 0<=lag<=maxlag else None


def reference_outcomes(ticks:pd.DataFrame, decisions:pd.DataFrame, policy:Policy=Policy()):
    """Choose first available quote at/after entry and expiry. No interpolated quotes.
    Expiry is anchored to ACTUAL sampled entry time, not candle close.
    Reference only: broker's own clock, quote and payout can differ.
    """
    cols=['decision_utc','entry_utc','settle_utc','entry_mid','settle_mid','entry_bid','entry_ask',
          'settle_bid','settle_ask','reference_move_pips','reference_direction','robust_direction',
          'quote_uncertainty_pips','entry_spread_pips']
    arr=ticks.timestamp_utc.astype('int64').to_numpy()
    bid=ticks.bid.to_numpy(dtype=float);ask=ticks.ask.to_numpy(dtype=float)
    rows=[]
    for d in decisions.itertuples(index=False):
        origin=pd.Timestamp(d.decision_utc)
        available=pd.Timestamp(getattr(d,'available_at_utc',origin))
        if available<origin or (available-origin).total_seconds()>policy.max_signal_age_seconds:
            continue
        entry_target=available+pd.Timedelta(seconds=policy.decision_latency_seconds)
        i=_pick(ticks,arr,entry_target,policy.max_entry_lag_seconds)
        if i is None: continue
        spread=(ask[i]-bid[i])/0.0001
        if spread>policy.max_entry_spread_pips:continue
        entry_time=pd.Timestamp(arr[i],tz='UTC')
        expiry_target=entry_time+pd.Timedelta(seconds=policy.expiry_seconds)
        j=_pick(ticks,arr,expiry_target,policy.max_exit_lag_seconds)
        if j is None:continue
        settle_time=pd.Timestamp(arr[j],tz='UTC')
        em=(bid[i]+ask[i])/2;xm=(bid[j]+ask[j])/2
        delta=(xm-em)/0.0001
        robust=('UP' if delta>policy.uncertainty_pips else 'DOWN' if delta < -policy.uncertainty_pips else 'UNCERTAIN')
        rows.append((origin,entry_time,settle_time,em,xm,bid[i],ask[i],bid[j],ask[j],delta,
                     'UP' if delta>0 else 'DOWN' if delta<0 else 'TIE',robust,policy.uncertainty_pips,spread))
    out=pd.DataFrame(rows,columns=cols)
    return out


def trade_payoff(signal, direction, payout, tie_policy):
    """Per 1 unit staked; simulation ONLY. Correct: +payout, wrong: -1."""
    if signal=='WAIT':return np.nan
    if signal not in ('CALL','PUT') or direction not in ('UP','DOWN','TIE'):
        raise ValueError('Invalid signal or outcome')
    if direction=='TIE':return 0.0 if tie_policy=='refund' else -1.0
    win=(signal=='CALL' and direction=='UP') or (signal=='PUT' and direction=='DOWN')
    return payout if win else -1.0


def robust_trade_bounds(signal, move_pips, policy):
    """Worst/best return with independent quote uncertainty; NOT broker verified.
    For an ambiguous difference, worst=-1 and best=+payout.
    """
    if signal=='WAIT':return np.nan,np.nan
    direction=1 if signal=='CALL' else -1
    if signal not in ('CALL','PUT'):raise ValueError('bad signal')
    signed=direction*float(move_pips)
    if signed > policy.uncertainty_pips:return policy.payout,policy.payout
    if signed < -policy.uncertainty_pips:return -1.0,-1.0
    return -1.0,policy.payout
