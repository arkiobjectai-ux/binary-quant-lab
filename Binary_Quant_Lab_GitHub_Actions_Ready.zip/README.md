# Binary Quant Lab — Binance Spot Research (GitHub Actions)

**Research and paper simulation only. No API keys, no authentication, no orders, no live trading.**

This repository contains a data-only integration with Binance public Spot endpoints and public historical archives, a provenance-aware M1 research dataset, illustrative CALL/PUT/WAIT baselines, and an optional 300-second last-trade proxy backtest if valid time-stamped aggTrades are supplied. It DOES NOT validate Pocket Option broker settlement. EURUSDT is not EURUSD FX.

## GitHub Actions

1. **Binary Quant Lab - unit tests**: runs on push, pull requests and manual dispatch; verifies deterministic tests.
2. **Binance - public data research**: nightly (06:18 UTC) downloads 720 recently *closed* one-minute BTCUSDT candles using the Binance read-only Spot API, validates coverage, and publishes a downloadable Actions artifact. Does not commit historical datasets to Git.
3. For manual archival ingestion: Actions → **Binance - public data research** → Run workflow → `mode=archive`, `symbol=BTCUSDT`, `day=YYYY-MM-DD`. Binance's official published daily Spot archive and its `.CHECKSUM` are both required. If either is missing, the job fails rather than fabricating data. Archive mode gets OHLCV only; exact 300s outcomes additionally need aggTrades.

No API key or secret is required. Failed downloads are real failures. GitHub Actions' network and Binance rate limits/geographic restrictions may affect access. Scheduled jobs can be delayed or disabled if the repository is inactive.

## Local use

Install Python 3.11, then:

```
python -m pip install -r requirements.txt
python -m pytest -q
python -m src.binance_public --symbol BTCUSDT --minutes 720 --out outputs/binance
python -m src.binance_history --symbol BTCUSDT --kind klines --day 2026-11-01 --out outputs/binance
python -m src.binance_strategies --bars outputs/binance/binance_m1_closed.csv --out outputs/signals
```

For a proxy outcome analysis, supply *same-symbol* time-stamped aggregate trades covering both signal availability and the exact 300-second exit. 1m OHLCV bars alone are not sufficient for validated expiry fills. The project's baseline outcomes are not Kronos-base inference.

## Data quality boundaries

- UTC timestamp validation; bars must be consecutive and fully closed.
- No lookahead, interpolation, or conversion between EURUSD FX and Binance crypto pairs.
- Archive SHA256 verification is required. Binance archive timestamp precision changes (Spot from Jan 2025) are handled.
- Broker entry/expiry values require **separate** user-authorized broker exports.
- Outputs and archives are downloaded as short-lived GitHub Actions artifacts; no private account access.

See `RESEARCH_STATUS_BINANCE_FA.md`, `docs/BINANCE_INTEGRATION_FA.md` for project background. Dependencies are bounded in `requirements.txt`.

## Manual exact-300s last-trade proxy research

Actions → **Binance - 300s proxy backtest (manual)** → Run workflow, supply `symbol`, an already-published UTC `day`, and hypothetical `payout`. The job downloads BOTH verified daily kline and daily aggTrades archives, generates baseline signals, and computes a *last-trade price proxy* result only when all quality gates pass. Archive size and 2-million-record safety caps can reject busy symbols such as BTCUSDT; reduce the research day or use a lower-volume symbol and inspect errors rather than weakening integrity rules. A daily archive lacks the next day's ticks for cross-midnight 300-second expiry and rejects such uncovered simulations. No broker settlement is implied.
